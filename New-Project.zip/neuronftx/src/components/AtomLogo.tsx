"use client"

import React from 'react'

export default function AtomLogo({ className = "w-10 h-10" }: { className?: string }) {
  return (
    <div className={`relative ${className}`}>
      <svg
        viewBox="0 0 100 100"
        className="w-full h-full atom-pulse"
        xmlns="http://www.w3.org/2000/svg"
      >
        {/* Central nucleus */}
        <circle
          cx="50"
          cy="50"
          r="8"
          className="fill-primary"
          style={{
            filter: 'drop-shadow(0 0 8px hsl(var(--neon-blue)))'
          }}
        />

        {/* Electron orbits */}
        <ellipse
          cx="50"
          cy="50"
          rx="35"
          ry="15"
          fill="none"
          stroke="hsl(var(--neon-blue))"
          strokeWidth="1.5"
          opacity="0.6"
          className="animate-spin"
          style={{ animationDuration: '3s' }}
        />

        <ellipse
          cx="50"
          cy="50"
          rx="35"
          ry="15"
          fill="none"
          stroke="hsl(var(--electric-blue))"
          strokeWidth="1.5"
          opacity="0.6"
          transform="rotate(60 50 50)"
          className="animate-spin"
          style={{ animationDuration: '4s', animationDirection: 'reverse' }}
        />

        <ellipse
          cx="50"
          cy="50"
          rx="35"
          ry="15"
          fill="none"
          stroke="hsl(var(--accent))"
          strokeWidth="1.5"
          opacity="0.6"
          transform="rotate(120 50 50)"
          className="animate-spin"
          style={{ animationDuration: '5s' }}
        />

        {/* Electrons */}
        <circle cx="85" cy="50" r="3" className="fill-electric-blue">
          <animateMotion
            dur="3s"
            repeatCount="indefinite"
            path="M 85,50 A 35,15 0 1,1 15,50 A 35,15 0 1,1 85,50"
          />
        </circle>

        <circle cx="73" cy="72" r="2.5" className="fill-neon-blue">
          <animateMotion
            dur="4s"
            repeatCount="indefinite"
            path="M 73,72 A 35,15 0 1,0 27,28 A 35,15 0 1,0 73,72"
          />
        </circle>

        <circle cx="27" cy="72" r="2" className="fill-accent">
          <animateMotion
            dur="5s"
            repeatCount="indefinite"
            path="M 27,72 A 35,15 0 1,1 73,28 A 35,15 0 1,1 27,72"
          />
        </circle>
      </svg>
    </div>
  )
}
