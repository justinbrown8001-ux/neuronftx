"use client"

import React from 'react'
import { Badge } from '@/components/ui/badge'

interface DomainDisplayProps {
  slug?: string
  showProtocol?: boolean
  className?: string
  copyable?: boolean
}

export default function DomainDisplay({
  slug = '',
  showProtocol = false,
  className = '',
  copyable = false
}: DomainDisplayProps) {
  const fullDomain = 'www.neuronftx.com'
  const fullURL = `${showProtocol ? 'https://' : ''}${fullDomain}${slug}`

  const handleCopy = () => {
    if (copyable) {
      navigator.clipboard.writeText(`https://${fullDomain}${slug}`)
    }
  }

  return (
    <div className={`inline-flex items-center space-x-2 ${className}`}>
      <code
        className={`bg-secondary/20 px-2 py-1 rounded font-mono text-sm ${
          copyable ? 'cursor-pointer hover:bg-secondary/30 transition-colors' : ''
        }`}
        onClick={handleCopy}
        title={copyable ? 'Click to copy' : ''}
      >
        {fullURL}
      </code>
      {copyable && (
        <Badge variant="outline" className="text-xs">
          Click to copy
        </Badge>
      )}
    </div>
  )
}

export const NEURONFTX_DOMAIN = 'www.neuronftx.com'
export const NEURONFTX_URL = `https://${NEURONFTX_DOMAIN}`
