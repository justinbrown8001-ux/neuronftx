"use client"

import React, { useState } from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'

export default function DomainBanner() {
  const [copied, setCopied] = useState(false)

  const handleCopyDomain = () => {
    navigator.clipboard.writeText('https://www.neuronftx.com')
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <Card className="neural-glow border-primary/30 bg-primary/5">
      <CardContent className="p-4">
        <div className="flex flex-col sm:flex-row items-center justify-between space-y-3 sm:space-y-0">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-primary/20 rounded-full flex items-center justify-center">
              <svg className="w-5 h-5 text-primary" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M12.586 4.586a2 2 0 112.828 2.828l-3 3a2 2 0 01-2.828 0 1 1 0 00-1.414 1.414 4 4 0 005.656 0l3-3a4 4 0 00-5.656-5.656l-1.5 1.5a1 1 0 101.414 1.414l1.5-1.5zm-5 5a2 2 0 012.828 0 1 1 0 101.414-1.414 4 4 0 00-5.656 0l-3 3a4 4 0 105.656 5.656l1.5-1.5a1 1 0 10-1.414-1.414l-1.5 1.5a2 2 0 11-2.828-2.828l3-3z" clipRule="evenodd" />
              </svg>
            </div>
            <div>
              <h3 className="font-semibold scientific-heading">Official NeuroNFTX Domain</h3>
              <div className="flex items-center space-x-2">
                <code className="text-sm bg-primary/10 px-2 py-1 rounded font-mono">
                  www.neuronftx.com
                </code>
                <Badge variant="default" className="text-xs">
                  Verified
                </Badge>
              </div>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <Button
              size="sm"
              variant="outline"
              onClick={handleCopyDomain}
              className="electric-border"
            >
              {copied ? '✅ Copied!' : '🔗 Copy Domain'}
            </Button>
            <div className="flex items-center space-x-1">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
              <span className="text-xs text-green-500 font-medium">Live</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
