"use client"

import React, { useRef, useEffect, useState } from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'

interface ThreeDViewerProps {
  modelUrl?: string
  title: string
  className?: string
}

export default function ThreeDViewer({ modelUrl, title, className = "" }: ThreeDViewerProps) {
  const mountRef = useRef<HTMLDivElement>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState(false)
  const [is3DMode, setIs3DMode] = useState(false)

  useEffect(() => {
    if (!is3DMode || !mountRef.current) return

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    let scene: any, camera: any, renderer: any, cube: any
    let animationId: number

    const initThreeJS = async () => {
      try {
        // Dynamically import Three.js to avoid SSR issues
        const THREE = await import('three')

        // Create scene
        scene = new THREE.Scene()
        scene.background = new THREE.Color(0x0a0a0f)

        // Create camera
        camera = new THREE.PerspectiveCamera(
          75,
          mountRef.current!.clientWidth / mountRef.current!.clientHeight,
          0.1,
          1000
        )

        // Create renderer
        renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true })
        renderer.setSize(mountRef.current!.clientWidth, mountRef.current!.clientHeight)
        renderer.shadowMap.enabled = true
        renderer.shadowMap.type = THREE.PCFSoftShadowMap
        mountRef.current!.appendChild(renderer.domElement)

        // Create a neural network-inspired geometry
        const geometry = new THREE.BoxGeometry(1, 1, 1)

        // Create wireframe material with glowing effect
        const material = new THREE.MeshPhongMaterial({
          color: 0x00bfff,
          wireframe: true,
          transparent: true,
          opacity: 0.8,
          emissive: 0x001122
        })

        cube = new THREE.Mesh(geometry, material)
        scene.add(cube)

        // Add some neural network nodes
        const nodeGeometry = new THREE.SphereGeometry(0.1, 8, 8)
        const nodeMaterial = new THREE.MeshPhongMaterial({
          color: 0x00ffff,
          emissive: 0x002244
        })

        for (let i = 0; i < 20; i++) {
          const node = new THREE.Mesh(nodeGeometry, nodeMaterial)
          node.position.set(
            (Math.random() - 0.5) * 4,
            (Math.random() - 0.5) * 4,
            (Math.random() - 0.5) * 4
          )
          scene.add(node)
        }

        // Add lighting
        const ambientLight = new THREE.AmbientLight(0x404040, 0.4)
        scene.add(ambientLight)

        const directionalLight = new THREE.DirectionalLight(0x00bfff, 0.8)
        directionalLight.position.set(5, 5, 5)
        directionalLight.castShadow = true
        scene.add(directionalLight)

        // Position camera
        camera.position.z = 3

        // Animation loop
        const animate = () => {
          animationId = requestAnimationFrame(animate)

          if (cube) {
            cube.rotation.x += 0.01
            cube.rotation.y += 0.01
          }

          // Animate neural nodes
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          scene.children.forEach((child: any) => {
            if (child.geometry && child.geometry.type === 'SphereGeometry') {
              child.rotation.x += 0.02
              child.rotation.y += 0.02

              // Pulsing effect
              const scale = 1 + Math.sin(Date.now() * 0.005 + child.position.x) * 0.3
              child.scale.setScalar(scale)
            }
          })

          renderer.render(scene, camera)
        }

        animate()
        setIsLoading(false)

        // Handle resize
        const currentMount = mountRef.current
        const handleResize = () => {
          if (!currentMount) return

          camera.aspect = currentMount.clientWidth / currentMount.clientHeight
          camera.updateProjectionMatrix()
          renderer.setSize(currentMount.clientWidth, currentMount.clientHeight)
        }

        window.addEventListener('resize', handleResize)

        return () => {
          window.removeEventListener('resize', handleResize)
        }

      } catch (err) {
        console.error('Failed to initialize 3D viewer:', err)
        setError(true)
        setIsLoading(false)
      }
    }

    initThreeJS()

    return () => {
      if (animationId) {
        cancelAnimationFrame(animationId)
      }
      const currentMount = mountRef.current
      if (renderer && currentMount?.contains(renderer.domElement)) {
        currentMount.removeChild(renderer.domElement)
      }
      if (renderer) {
        renderer.dispose()
      }
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [is3DMode])

  if (!is3DMode) {
    return (
      <Card className={`neural-glow ${className}`}>
        <CardContent className="p-6">
          <div className="text-center space-y-4">
            <div className="w-20 h-20 mx-auto bg-primary/20 rounded-full flex items-center justify-center">
              <svg className="w-10 h-10 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9v-9m0-9v9" />
              </svg>
            </div>
            <div>
              <h3 className="text-lg font-semibold scientific-heading mb-2">3D Neural Viewer</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Experience {title} in immersive 3D with neural network visualization
              </p>
              <Button
                onClick={() => setIs3DMode(true)}
                className="neural-glow hover:glow-effect transition-all duration-300"
              >
                Launch 3D Viewer
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    )
  }

  if (error) {
    return (
      <Card className={`neural-glow ${className}`}>
        <CardContent className="p-6">
          <div className="text-center space-y-4">
            <div className="w-20 h-20 mx-auto bg-red-500/20 rounded-full flex items-center justify-center">
              <svg className="w-10 h-10 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.888-.833-2.598 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z" />
              </svg>
            </div>
            <div>
              <h3 className="text-lg font-semibold text-red-500 mb-2">3D Viewer Error</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Failed to initialize 3D viewer. Your browser may not support WebGL.
              </p>
              <Button
                variant="outline"
                onClick={() => setIs3DMode(false)}
              >
                Back to 2D View
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className={`neural-glow ${className}`}>
      <CardContent className="p-0">
        <div className="relative">
          {isLoading && (
            <div className="absolute inset-0 flex items-center justify-center bg-background/80 z-10">
              <div className="text-center space-y-2">
                <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto"></div>
                <p className="text-sm text-muted-foreground">Initializing Neural 3D Viewer...</p>
              </div>
            </div>
          )}
          <div ref={mountRef} className="w-full h-96 rounded-lg overflow-hidden" />
          <div className="absolute bottom-4 left-4 right-4 flex justify-between items-center">
            <div className="bg-background/80 backdrop-blur-sm rounded-lg px-3 py-2">
              <p className="text-sm font-medium">{title}</p>
              <p className="text-xs text-muted-foreground">3D Neural Visualization</p>
            </div>
            <div className="flex space-x-2">
              <Button
                size="sm"
                variant="outline"
                onClick={() => setIs3DMode(false)}
                className="bg-background/80 backdrop-blur-sm"
              >
                Exit 3D
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
