"use client"

import React, { useState } from 'react'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { useWeb3 } from '@/contexts/Web3Context'

interface WalletModalProps {
  isOpen: boolean
  onClose: () => void
}

export default function WalletModal({ isOpen, onClose }: WalletModalProps) {
  const { connectWallet, isConnecting } = useWeb3()
  const [connectingWallet, setConnectingWallet] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const wallets = [
    {
      name: 'MetaMask',
      icon: '🦊',
      description: 'Connect using MetaMask wallet',
      popular: true,
      installed: typeof window !== 'undefined' && window.ethereum?.isMetaMask
    },
    {
      name: 'WalletConnect',
      icon: '🔗',
      description: 'Scan with WalletConnect to connect',
      popular: true,
      installed: true
    },
    {
      name: 'Coinbase Wallet',
      icon: '💰',
      description: 'Connect using Coinbase wallet',
      popular: false,
      installed: typeof window !== 'undefined' && window.ethereum?.isCoinbaseWallet
    },
    {
      name: 'Phantom',
      icon: '👻',
      description: 'For Solana-based NFTs',
      popular: false,
      installed: typeof window !== 'undefined' && window.solana?.isPhantom
    },
    {
      name: 'Trust Wallet',
      icon: '🛡️',
      description: 'Connect using Trust Wallet',
      popular: false,
      installed: false
    },
    {
      name: 'Rainbow',
      icon: '🌈',
      description: 'Connect using Rainbow wallet',
      popular: false,
      installed: false
    }
  ]

  const handleWalletConnect = async (walletName: string) => {
    setConnectingWallet(walletName)
    setError(null)

    try {
      await connectWallet(walletName)
      onClose()
    } catch (error: any) {
      setError(error.message || 'Failed to connect wallet')
    } finally {
      setConnectingWallet(null)
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="neural-glow max-w-md">
        <DialogHeader>
          <DialogTitle className="scientific-heading text-center text-2xl">
            Connect Neural Wallet
          </DialogTitle>
          <p className="text-center text-muted-foreground">
            Choose your preferred wallet to access the NeuroNFTX ecosystem
          </p>
        </DialogHeader>

        {error && (
          <div className="mb-4 p-3 bg-red-500/10 border border-red-500/20 rounded-lg">
            <p className="text-sm text-red-400">{error}</p>
          </div>
        )}

        <div className="space-y-4 mt-6">
          {wallets.map((wallet) => (
            <Card
              key={wallet.name}
              className={`neural-glow hover:glow-effect transition-all duration-300 cursor-pointer group ${
                connectingWallet === wallet.name ? 'opacity-50 cursor-not-allowed' : ''
              }`}
              onClick={() => !connectingWallet && handleWalletConnect(wallet.name)}
            >
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-primary/20 rounded-full flex items-center justify-center text-2xl group-hover:scale-110 transition-transform">
                      {wallet.icon}
                    </div>
                    <div>
                      <div className="flex items-center space-x-2">
                        <h3 className="font-semibold">{wallet.name}</h3>
                        {wallet.popular && (
                          <Badge variant="secondary" className="text-xs">
                            Popular
                          </Badge>
                        )}
                        {wallet.installed && (
                          <Badge variant="default" className="text-xs electric-border">
                            Detected
                          </Badge>
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground">
                        {wallet.description}
                      </p>
                    </div>
                  </div>
                  <div className="w-6 h-6 border-2 border-primary rounded-full flex items-center justify-center transition-opacity">
                    {connectingWallet === wallet.name ? (
                      <div className="w-4 h-4 border-2 border-primary border-t-transparent rounded-full animate-spin"></div>
                    ) : (
                      <div className="w-2 h-2 bg-primary rounded-full atom-pulse opacity-0 group-hover:opacity-100"></div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-6 space-y-4">
          <div className="text-center">
            <p className="text-xs text-muted-foreground">
              By connecting a wallet, you agree to NeuroNFTX's{' '}
              <a href="#" className="text-primary hover:underline">
                Terms of Service
              </a>{' '}
              and{' '}
              <a href="#" className="text-primary hover:underline">
                Privacy Policy
              </a>
            </p>
          </div>

          <div className="flex items-center justify-center space-x-4 text-xs text-muted-foreground">
            <div className="flex items-center space-x-1">
              <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
              <span>Quantum Secured</span>
            </div>
            <div className="flex items-center space-x-1">
              <div className="w-3 h-3 bg-primary rounded-full animate-pulse"></div>
              <span>Neural Protected</span>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
