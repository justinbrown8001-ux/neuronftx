"use client"

import React, { useState } from 'react'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import AtomLogo from './AtomLogo'
import WalletModal from './WalletModal'
import { useWeb3 } from '@/contexts/Web3Context'

export default function Header() {
  const [isWalletModalOpen, setIsWalletModalOpen] = useState(false)
  const { isConnected, account, disconnectWallet } = useWeb3()

  const navItems = [
    { name: 'Marketplace', href: '/marketplace' },
    { name: 'Create', href: '/create' },
    { name: 'Analytics', href: '/analytics' },
    { name: 'Dashboard', href: '/dashboard' },
    { name: 'Page Registrar', href: '/page-registrar' },
    { name: 'Demo Pages', href: '/demo-pages' },
    { name: 'Admin', href: '/admin' }
  ]

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto flex h-16 items-center justify-between px-4">
        {/* Logo and Brand */}
        <Link href="/" className="flex items-center space-x-3 group">
          <AtomLogo className="w-10 h-10 transition-transform group-hover:scale-110" />
          <div>
            <h1 className="text-xl font-bold scientific-heading">NeuroNFTX</h1>
            <p className="text-xs text-muted-foreground font-mono">Neural Exchange</p>
          </div>
        </Link>

        {/* Navigation Menu */}
        <nav className="hidden md:flex items-center space-x-6">
          {navItems.map((item) => (
            <Link
              key={item.name}
              href={item.href}
              className="text-sm font-medium text-foreground/80 hover:text-primary transition-colors duration-200 hover:glow-effect rounded-md px-3 py-2"
            >
              {item.name}
            </Link>
          ))}
        </nav>

        {/* Right Side Actions */}
        <div className="flex items-center space-x-4">
          {/* Connection Status */}
          {isConnected && (
            <Badge variant="outline" className="hidden sm:inline-flex electric-border">
              <div className="w-2 h-2 bg-green-500 rounded-full mr-2 atom-pulse"></div>
              Connected
            </Badge>
          )}

          {/* Wallet Connect/Disconnect Button */}
          {isConnected ? (
            <div className="flex items-center space-x-2">
              <Button
                variant="outline"
                size="sm"
                className="neural-glow font-mono"
              >
                {account ? `${account.slice(0, 6)}...${account.slice(-4)}` : 'Connected'}
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={disconnectWallet}
                className="text-red-400 hover:text-red-300"
              >
                Disconnect
              </Button>
            </div>
          ) : (
            <Button
              className="neural-glow hover:glow-effect transition-all duration-300"
              size="sm"
              onClick={() => setIsWalletModalOpen(true)}
            >
              Connect Wallet
            </Button>
          )}

          {/* Mobile Menu Toggle */}
          <Button
            variant="ghost"
            size="sm"
            className="md:hidden"
          >
            <svg
              className="w-5 h-5"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M4 6h16M4 12h16M4 18h16"
              />
            </svg>
          </Button>
        </div>
      </div>

      <WalletModal
        isOpen={isWalletModalOpen}
        onClose={() => setIsWalletModalOpen(false)}
      />
    </header>
  )
}
