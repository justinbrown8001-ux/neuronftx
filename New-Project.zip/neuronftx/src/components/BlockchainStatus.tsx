"use client"

import React, { useState, useEffect } from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { useWeb3 } from '@/contexts/Web3Context'

export default function BlockchainStatus() {
  const { isConnected, chainId, switchNetwork, getGasPrice, provider } = useWeb3()
  const [gasPrice, setGasPrice] = useState<string>('0')
  const [blockNumber, setBlockNumber] = useState<number>(0)

  const networks = {
    1: { name: 'Ethereum', color: 'bg-blue-500', symbol: 'ETH' },
    11155111: { name: 'Sepolia', color: 'bg-purple-500', symbol: 'SEP' },
    137: { name: 'Polygon', color: 'bg-purple-600', symbol: 'MATIC' },
    80001: { name: 'Mumbai', color: 'bg-orange-500', symbol: 'MATIC' }
  }

  useEffect(() => {
    const updateBlockchainData = async () => {
      if (!isConnected || !provider) return

      try {
        const [gas, block] = await Promise.all([
          getGasPrice(),
          provider.getBlockNumber()
        ])

        setGasPrice(gas)
        setBlockNumber(block)
      } catch (error) {
        console.error('Failed to fetch blockchain data:', error)
      }
    }

    updateBlockchainData()

    // Update every 15 seconds
    const interval = setInterval(updateBlockchainData, 15000)
    return () => clearInterval(interval)
  }, [isConnected, provider, getGasPrice])

  const handleNetworkSwitch = async (networkId: number) => {
    try {
      await switchNetwork(networkId)
    } catch (error) {
      console.error('Failed to switch network:', error)
    }
  }

  if (!isConnected) {
    return (
      <Card className="neural-glow">
        <CardContent className="p-4">
          <div className="text-center space-y-2">
            <div className="w-8 h-8 bg-yellow-500/20 rounded-full flex items-center justify-center mx-auto">
              <svg className="w-4 h-4 text-yellow-500" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
              </svg>
            </div>
            <p className="text-sm text-muted-foreground">Wallet not connected</p>
            <p className="text-xs text-muted-foreground">Connect your wallet to view blockchain status</p>
          </div>
        </CardContent>
      </Card>
    )
  }

  const currentNetwork = networks[chainId as keyof typeof networks]

  return (
    <Card className="neural-glow">
      <CardContent className="p-4">
        <div className="space-y-4">
          {/* Network Status */}
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className={`w-3 h-3 rounded-full ${currentNetwork?.color || 'bg-gray-500'} animate-pulse`}></div>
              <span className="text-sm font-medium">
                {currentNetwork?.name || `Network ${chainId}`}
              </span>
            </div>
            <Badge variant="outline" className="text-xs electric-border">
              Block {blockNumber.toLocaleString()}
            </Badge>
          </div>

          {/* Gas Price */}
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground">Gas Price</span>
            <div className="flex items-center space-x-1">
              <span className="text-sm font-medium">{Number.parseFloat(gasPrice).toFixed(1)} Gwei</span>
              <div className={`w-2 h-2 rounded-full ${
                Number.parseFloat(gasPrice) < 20 ? 'bg-green-500' :
                Number.parseFloat(gasPrice) < 50 ? 'bg-yellow-500' : 'bg-red-500'
              }`}></div>
            </div>
          </div>

          {/* Network Switcher */}
          <div className="space-y-2">
            <p className="text-xs text-muted-foreground">Quick Switch Networks</p>
            <div className="grid grid-cols-2 gap-2">
              {Object.entries(networks).map(([id, network]) => (
                <Button
                  key={id}
                  variant={Number(id) === chainId ? "default" : "outline"}
                  size="sm"
                  className="text-xs"
                  onClick={() => handleNetworkSwitch(Number(id))}
                  disabled={Number(id) === chainId}
                >
                  {network.name}
                </Button>
              ))}
            </div>
          </div>

          {/* Status Indicators */}
          <div className="grid grid-cols-3 gap-2 text-center">
            <div className="space-y-1">
              <div className="w-4 h-4 bg-green-500 rounded-full mx-auto animate-pulse"></div>
              <p className="text-xs text-muted-foreground">Connected</p>
            </div>
            <div className="space-y-1">
              <div className="w-4 h-4 bg-blue-500 rounded-full mx-auto animate-pulse"></div>
              <p className="text-xs text-muted-foreground">Synced</p>
            </div>
            <div className="space-y-1">
              <div className="w-4 h-4 bg-primary rounded-full mx-auto animate-pulse"></div>
              <p className="text-xs text-muted-foreground">Neural</p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
