"use client"

import React from 'react'
import { Button } from '@/components/ui/button'
import Header from '@/components/Header'
import ParticleBackground from '@/components/ParticleBackground'
import NFTCard from '@/components/NFTCard'
import DomainBanner from '@/components/DomainBanner'

export default function Home() {
  // Mock NFT data
  const featuredNFTs = [
    {
      title: "Neural Pathways #001",
      creator: "Dr. CyberArt",
      price: "2.5",
      image: "https://picsum.photos/400/400?random=1",
      rarity: "Legendary",
      isVerified: true
    },
    {
      title: "Quantum Neurons",
      creator: "NeuralMind",
      price: "1.8",
      image: "https://picsum.photos/400/400?random=2",
      rarity: "Rare",
      isVerified: true
    },
    {
      title: "Synaptic Storm",
      creator: "BrainWave",
      price: "3.2",
      image: "https://picsum.photos/400/400?random=3",
      rarity: "Epic",
      isVerified: false
    },
    {
      title: "Atomic Dreams",
      creator: "QuantumArt",
      price: "1.2",
      image: "https://picsum.photos/400/400?random=4",
      rarity: "Common",
      isVerified: true
    }
  ]

  return (
    <main className="relative min-h-screen">
      <ParticleBackground />
      <Header />

      <div className="relative z-10">
        {/* Domain Banner */}
        <div className="container mx-auto px-4 pt-6">
          <DomainBanner />
        </div>

        {/* Hero Section */}
        <section className="container mx-auto px-4 py-24">
          <div className="max-w-4xl mx-auto text-center space-y-8">
            <div className="space-y-4">
              <h1 className="text-6xl md:text-8xl font-bold scientific-heading">
                NeuroNFTX
              </h1>
              <p className="text-xl md:text-2xl text-muted-foreground max-w-2xl mx-auto">
                Where Neural Networks Meet Digital Art. Discover, Create, and Trade
                Revolutionary NFTs in the Scientific Metaverse at <span className="text-primary font-semibold">www.neuronftx.com</span>
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                size="lg"
                className="neural-glow hover:glow-effect transition-all duration-300 text-lg px-8 py-6"
              >
                Explore NFTs
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="electric-border text-lg px-8 py-6"
              >
                Sell Yours
              </Button>
            </div>

            {/* Scientific Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mt-16">
              <div className="space-y-2">
                <div className="text-3xl font-bold scientific-heading">12.5K</div>
                <div className="text-sm text-muted-foreground">Neural Arts</div>
              </div>
              <div className="space-y-2">
                <div className="text-3xl font-bold scientific-heading">8.2K</div>
                <div className="text-sm text-muted-foreground">Researchers</div>
              </div>
              <div className="space-y-2">
                <div className="text-3xl font-bold scientific-heading">156</div>
                <div className="text-sm text-muted-foreground">ETH Volume</div>
              </div>
              <div className="space-y-2">
                <div className="text-3xl font-bold scientific-heading">2.8K</div>
                <div className="text-sm text-muted-foreground">Experiments</div>
              </div>
            </div>
          </div>
        </section>

        {/* Featured NFTs Section */}
        <section className="container mx-auto px-4 py-16">
          <div className="space-y-8">
            <div className="text-center space-y-4">
              <h2 className="text-4xl font-bold scientific-heading">
                Featured Neural Collections
              </h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Discover groundbreaking digital art created by leading scientists and AI researchers
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {featuredNFTs.map((nft, index) => (
                <NFTCard key={index} {...nft} />
              ))}
            </div>

            <div className="text-center">
              <Button
                variant="outline"
                size="lg"
                className="electric-border"
              >
                View All Collections
              </Button>
            </div>
          </div>
        </section>

        {/* Scientific Features Section */}
        <section className="container mx-auto px-4 py-16">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center space-y-4 p-6 neural-glow rounded-lg">
              <div className="w-16 h-16 mx-auto bg-primary/20 rounded-full flex items-center justify-center">
                <svg className="w-8 h-8 text-primary" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                </svg>
              </div>
              <h3 className="text-xl font-bold scientific-heading">Verified Research</h3>
              <p className="text-muted-foreground">
                All NFTs are verified by our scientific committee ensuring authenticity and innovation
              </p>
            </div>

            <div className="text-center space-y-4 p-6 neural-glow rounded-lg">
              <div className="w-16 h-16 mx-auto bg-primary/20 rounded-full flex items-center justify-center">
                <svg className="w-8 h-8 text-primary" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M13 6a3 3 0 11-6 0 3 3 0 016 0zM18 8a2 2 0 11-4 0 2 2 0 014 0zM14 15a4 4 0 00-8 0v3h8v-3z"/>
                </svg>
              </div>
              <h3 className="text-xl font-bold scientific-heading">Neural Networks</h3>
              <p className="text-muted-foreground">
                Powered by advanced AI algorithms for intelligent pricing and discovery
              </p>
            </div>

            <div className="text-center space-y-4 p-6 neural-glow rounded-lg">
              <div className="w-16 h-16 mx-auto bg-primary/20 rounded-full flex items-center justify-center">
                <svg className="w-8 h-8 text-primary" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M3 4a1 1 0 011-1h12a1 1 0 011 1v2a1 1 0 01-1 1H4a1 1 0 01-1-1V4zM3 10a1 1 0 011-1h6a1 1 0 011 1v6a1 1 0 01-1 1H4a1 1 0 01-1-1v-6zM14 9a1 1 0 00-1 1v6a1 1 0 001 1h2a1 1 0 001-1v-6a1 1 0 00-1-1h-2z"/>
                </svg>
              </div>
              <h3 className="text-xl font-bold scientific-heading">Quantum Security</h3>
              <p className="text-muted-foreground">
                Ultra-secure blockchain technology with quantum-resistant encryption protocols
              </p>
            </div>
          </div>
        </section>
      </div>
    </main>
  )
}
