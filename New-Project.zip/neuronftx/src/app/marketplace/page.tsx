"use client"

import React, { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import Header from '@/components/Header'
import NFTCard from '@/components/NFTCard'

export default function Marketplace() {
  const [selectedCategory, setSelectedCategory] = useState('All')
  const [selectedRarity, setSelectedRarity] = useState('All')
  const [priceRange, setPriceRange] = useState([0, 10])

  // Mock NFT data for marketplace
  const allNFTs = [
    {
      title: "Neural Pathways #001",
      creator: "Dr. CyberArt",
      price: "2.5",
      image: "https://picsum.photos/400/400?random=1",
      rarity: "Legendary",
      category: "Science",
      isVerified: true
    },
    {
      title: "Quantum Neurons",
      creator: "NeuralMind",
      price: "1.8",
      image: "https://picsum.photos/400/400?random=2",
      rarity: "Rare",
      category: "Art",
      isVerified: true
    },
    {
      title: "Synaptic Storm",
      creator: "BrainWave",
      price: "3.2",
      image: "https://picsum.photos/400/400?random=3",
      rarity: "Epic",
      category: "Game",
      isVerified: false
    },
    {
      title: "Atomic Dreams",
      creator: "QuantumArt",
      price: "1.2",
      image: "https://picsum.photos/400/400?random=4",
      rarity: "Common",
      category: "Music",
      isVerified: true
    },
    {
      title: "DNA Helix Visualization",
      creator: "BioTech",
      price: "4.5",
      image: "https://picsum.photos/400/400?random=5",
      rarity: "Legendary",
      category: "Science",
      isVerified: true
    },
    {
      title: "Molecular Structure",
      creator: "ChemArt",
      price: "2.1",
      image: "https://picsum.photos/400/400?random=6",
      rarity: "Rare",
      category: "Science",
      isVerified: true
    },
    {
      title: "Electric Fields",
      creator: "PhysicsViz",
      price: "1.9",
      image: "https://picsum.photos/400/400?random=7",
      rarity: "Epic",
      category: "Art",
      isVerified: false
    },
    {
      title: "Cosmic Radiation",
      creator: "SpaceArt",
      price: "3.8",
      image: "https://picsum.photos/400/400?random=8",
      rarity: "Legendary",
      category: "Science",
      isVerified: true
    }
  ]

  const categories = ['All', 'Art', 'Game', 'Music', 'Science']
  const rarities = ['All', 'Common', 'Rare', 'Epic', 'Legendary']

  const filteredNFTs = allNFTs.filter(nft => {
    const categoryMatch = selectedCategory === 'All' || nft.category === selectedCategory
    const rarityMatch = selectedRarity === 'All' || nft.rarity === selectedRarity
    const priceMatch = Number.parseFloat(nft.price) >= priceRange[0] && Number.parseFloat(nft.price) <= priceRange[1]
    return categoryMatch && rarityMatch && priceMatch
  })

  return (
    <main className="min-h-screen bg-background">
      <Header />

      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold scientific-heading mb-2">
            Neural Marketplace
          </h1>
          <p className="text-lg text-muted-foreground">
            Discover and collect revolutionary digital art from the scientific community
          </p>
        </div>

        <div className="flex flex-col lg:flex-row gap-8">
          {/* Filters Sidebar */}
          <div className="lg:w-80 space-y-6">
            <Card className="neural-glow">
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold scientific-heading mb-4">Filters</h3>

                {/* Category Filter */}
                <div className="space-y-3 mb-6">
                  <h4 className="text-sm font-medium text-foreground">Category</h4>
                  <div className="space-y-2">
                    {categories.map((category) => (
                      <Button
                        key={category}
                        variant={selectedCategory === category ? "default" : "ghost"}
                        size="sm"
                        className="w-full justify-start"
                        onClick={() => setSelectedCategory(category)}
                      >
                        {category}
                      </Button>
                    ))}
                  </div>
                </div>

                {/* Rarity Filter */}
                <div className="space-y-3 mb-6">
                  <h4 className="text-sm font-medium text-foreground">Rarity</h4>
                  <div className="space-y-2">
                    {rarities.map((rarity) => (
                      <Button
                        key={rarity}
                        variant={selectedRarity === rarity ? "default" : "ghost"}
                        size="sm"
                        className="w-full justify-start"
                        onClick={() => setSelectedRarity(rarity)}
                      >
                        {rarity}
                      </Button>
                    ))}
                  </div>
                </div>

                {/* Price Range */}
                <div className="space-y-3">
                  <h4 className="text-sm font-medium text-foreground">Price Range (ETH)</h4>
                  <div className="space-y-2">
                    <div className="flex items-center space-x-2">
                      <input
                        type="range"
                        min="0"
                        max="10"
                        step="0.1"
                        value={priceRange[0]}
                        onChange={(e) => setPriceRange([Number.parseFloat(e.target.value), priceRange[1]])}
                        className="flex-1"
                      />
                    </div>
                    <div className="flex items-center space-x-2">
                      <input
                        type="range"
                        min="0"
                        max="10"
                        step="0.1"
                        value={priceRange[1]}
                        onChange={(e) => setPriceRange([priceRange[0], Number.parseFloat(e.target.value)])}
                        className="flex-1"
                      />
                    </div>
                    <div className="flex justify-between text-xs text-muted-foreground">
                      <span>{priceRange[0]} ETH</span>
                      <span>{priceRange[1]} ETH</span>
                    </div>
                  </div>
                </div>

                {/* Clear Filters */}
                <Button
                  variant="outline"
                  size="sm"
                  className="w-full mt-4"
                  onClick={() => {
                    setSelectedCategory('All')
                    setSelectedRarity('All')
                    setPriceRange([0, 10])
                  }}
                >
                  Clear Filters
                </Button>
              </CardContent>
            </Card>

            {/* Quick Stats */}
            <Card className="neural-glow">
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold scientific-heading mb-4">Market Stats</h3>
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Total Volume</span>
                    <span className="text-sm font-medium">156 ETH</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Floor Price</span>
                    <span className="text-sm font-medium">0.8 ETH</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Listed Items</span>
                    <span className="text-sm font-medium">{filteredNFTs.length}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="flex-1">
            {/* Sort Options */}
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center space-x-4">
                <Badge variant="outline" className="electric-border">
                  {filteredNFTs.length} items found
                </Badge>
              </div>

              <div className="flex items-center space-x-2">
                <span className="text-sm text-muted-foreground">Sort by:</span>
                <select className="bg-background border border-border rounded-md px-3 py-1 text-sm">
                  <option>Trending</option>
                  <option>Newest</option>
                  <option>Price: Low to High</option>
                  <option>Price: High to Low</option>
                  <option>Most Liked</option>
                  <option>Ending Soon</option>
                </select>
              </div>
            </div>

            {/* NFT Grid */}
            {filteredNFTs.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4 gap-6">
                {filteredNFTs.map((nft, index) => (
                  <NFTCard key={index} {...nft} />
                ))}
              </div>
            ) : (
              <div className="text-center py-16">
                <div className="w-24 h-24 mx-auto mb-4 bg-primary/10 rounded-full flex items-center justify-center">
                  <svg className="w-12 h-12 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.172 16.172a4 4 0 015.656 0M9 12h6m-6-4h6m2 5.291A7.962 7.962 0 0112 15c-2.34 0-4.462-.881-6.065-2.328m0 0A7.963 7.963 0 014 9c0-4.418 3.582-8 8-8s8 3.582 8 8c0 1.508-.418 2.922-1.149 4.149M6.065 12.672A7.963 7.963 0 014 9" />
                  </svg>
                </div>
                <h3 className="text-lg font-semibold mb-2">No NFTs Found</h3>
                <p className="text-muted-foreground">Try adjusting your filters to see more results</p>
              </div>
            )}

            {/* Load More */}
            {filteredNFTs.length > 0 && (
              <div className="text-center mt-12">
                <Button variant="outline" size="lg" className="electric-border">
                  Load More NFTs
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </main>
  )
}
