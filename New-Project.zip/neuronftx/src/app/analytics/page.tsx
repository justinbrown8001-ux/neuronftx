"use client"

import React from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import Header from '@/components/Header'

export default function AnalyticsPage() {
  // Mock data for analytics
  const marketStats = {
    totalVolume: '2,456',
    totalSales: '8,392',
    averagePrice: '1.8',
    activeTraders: '2,149'
  }

  const topCollections = [
    { name: 'Neural Pathways', volume: '156.2', change: '+12.5', floor: '2.1' },
    { name: 'Quantum Dreams', volume: '134.8', change: '+8.3', floor: '1.9' },
    { name: 'Molecular Art', volume: '98.4', change: '-2.1', floor: '1.2' },
    { name: 'Space Biology', volume: '87.6', change: '+15.2', floor: '3.4' },
    { name: 'Neural Networks', volume: '76.3', change: '+5.7', floor: '0.8' }
  ]

  const recentSales = [
    { nft: 'Neural Pathway #001', price: '4.2', buyer: '0x1234...5678', time: '2 min ago' },
    { nft: 'Quantum Brain #045', price: '3.8', buyer: '0x9876...4321', time: '5 min ago' },
    { nft: 'DNA Helix #023', price: '2.1', buyer: '0x5555...8888', time: '8 min ago' },
    { nft: 'Molecular Bond #067', price: '1.9', buyer: '0x7777...9999', time: '12 min ago' },
    { nft: 'Synaptic Storm #012', price: '2.7', buyer: '0x3333...1111', time: '15 min ago' }
  ]

  const volumeData = [
    { day: 'Mon', volume: 45 },
    { day: 'Tue', volume: 67 },
    { day: 'Wed', volume: 89 },
    { day: 'Thu', volume: 123 },
    { day: 'Fri', volume: 156 },
    { day: 'Sat', volume: 134 },
    { day: 'Sun', volume: 98 }
  ]

  const maxVolume = Math.max(...volumeData.map(d => d.volume))

  const categoryData = [
    { category: 'Neural Networks', percentage: 35, volume: '856.2', color: 'bg-blue-500' },
    { category: 'Quantum Physics', percentage: 28, volume: '687.4', color: 'bg-purple-500' },
    { category: 'Molecular Biology', percentage: 22, volume: '539.1', color: 'bg-green-500' },
    { category: 'Space Science', percentage: 15, volume: '367.8', color: 'bg-orange-500' }
  ]

  return (
    <main className="min-h-screen bg-background">
      <Header />

      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold scientific-heading mb-2">
            Neural Analytics
          </h1>
          <p className="text-lg text-muted-foreground">
            Real-time insights into the NeuroNFTX marketplace ecosystem
          </p>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-8">
          <Card className="neural-glow">
            <CardContent className="p-6 text-center">
              <h3 className="text-3xl font-bold scientific-heading">{marketStats.totalVolume}</h3>
              <p className="text-sm text-muted-foreground">Total Volume (ETH)</p>
              <p className="text-xs text-green-500 mt-1">+18.2% today</p>
            </CardContent>
          </Card>
          <Card className="neural-glow">
            <CardContent className="p-6 text-center">
              <h3 className="text-3xl font-bold scientific-heading">{marketStats.totalSales}</h3>
              <p className="text-sm text-muted-foreground">Total Sales</p>
              <p className="text-xs text-primary mt-1">+5.7% today</p>
            </CardContent>
          </Card>
          <Card className="neural-glow">
            <CardContent className="p-6 text-center">
              <h3 className="text-3xl font-bold scientific-heading">{marketStats.averagePrice}</h3>
              <p className="text-sm text-muted-foreground">Avg Price (ETH)</p>
              <p className="text-xs text-green-500 mt-1">+12.3% today</p>
            </CardContent>
          </Card>
          <Card className="neural-glow">
            <CardContent className="p-6 text-center">
              <h3 className="text-3xl font-bold scientific-heading">{marketStats.activeTraders}</h3>
              <p className="text-sm text-muted-foreground">Active Traders</p>
              <p className="text-xs text-primary mt-1">+8.9% today</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* Daily Volume Chart */}
          <Card className="neural-glow">
            <CardHeader>
              <CardTitle className="scientific-heading">Daily Trading Volume</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {volumeData.map((data, index) => (
                  <div key={index} className="flex items-center justify-between">
                    <span className="text-sm font-medium w-12">{data.day}</span>
                    <div className="flex items-center space-x-2 flex-1 ml-4">
                      <div className="flex-1 bg-secondary/20 rounded-full h-3">
                        <div
                          className="bg-gradient-to-r from-primary to-blue-400 h-3 rounded-full transition-all duration-500 glow-effect"
                          style={{ width: `${(data.volume / maxVolume) * 100}%` }}
                        />
                      </div>
                      <span className="text-sm font-semibold w-16 text-right">{data.volume} ETH</span>
                    </div>
                  </div>
                ))}
              </div>
              <div className="mt-4 pt-4 border-t border-border">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Weekly Total:</span>
                  <span className="font-bold">712 ETH</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Category Breakdown */}
          <Card className="neural-glow">
            <CardHeader>
              <CardTitle className="scientific-heading">Category Performance</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {categoryData.map((cat, index) => (
                  <div key={index} className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="font-medium">{cat.category}</span>
                      <div className="text-right">
                        <div className="text-sm font-bold">{cat.volume} ETH</div>
                        <div className="text-xs text-muted-foreground">{cat.percentage}%</div>
                      </div>
                    </div>
                    <div className="w-full bg-secondary/20 rounded-full h-2">
                      <div
                        className={`${cat.color} h-2 rounded-full transition-all duration-500`}
                        style={{ width: `${cat.percentage}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Top Collections */}
          <Card className="neural-glow">
            <CardHeader>
              <CardTitle className="scientific-heading">Top Collections (24h)</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {topCollections.map((collection, index) => (
                  <div key={index} className="flex items-center justify-between p-3 rounded-lg hover:bg-secondary/10 transition-colors">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-primary/20 rounded-full flex items-center justify-center font-bold">
                        {index + 1}
                      </div>
                      <div>
                        <h3 className="font-semibold">{collection.name}</h3>
                        <p className="text-xs text-muted-foreground">Floor: {collection.floor} ETH</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-bold">{collection.volume} ETH</p>
                      <Badge
                        variant={collection.change.startsWith('+') ? 'default' : 'destructive'}
                        className="text-xs"
                      >
                        {collection.change}%
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Live Sales Feed */}
          <Card className="neural-glow">
            <CardHeader>
              <CardTitle className="scientific-heading flex items-center">
                Live Sales Feed
                <div className="ml-2 w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentSales.map((sale, index) => (
                  <div key={index} className="flex items-center justify-between p-3 rounded-lg bg-secondary/10">
                    <div>
                      <h3 className="font-semibold text-sm">{sale.nft}</h3>
                      <p className="text-xs text-muted-foreground">
                        by {sale.buyer} • {sale.time}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-primary">{sale.price} ETH</p>
                      <p className="text-xs text-muted-foreground">≈ ${(Number.parseFloat(sale.price) * 2340).toFixed(0)}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Market Insights */}
        <div className="mt-8">
          <Card className="neural-glow">
            <CardHeader>
              <CardTitle className="scientific-heading">Market Insights</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="text-center p-4 neural-glow rounded-lg">
                  <div className="w-12 h-12 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-3">
                    <svg className="w-6 h-6 text-green-500" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M3.293 9.707a1 1 0 010-1.414l6-6a1 1 0 011.414 0l6 6a1 1 0 01-1.414 1.414L11 5.414V17a1 1 0 11-2 0V5.414L4.707 9.707a1 1 0 01-1.414 0z" clipRule="evenodd" />
                    </svg>
                  </div>
                  <h3 className="font-bold text-green-500">Bull Market</h3>
                  <p className="text-sm text-muted-foreground">Strong upward trend in neural NFTs</p>
                </div>

                <div className="text-center p-4 neural-glow rounded-lg">
                  <div className="w-12 h-12 bg-blue-500/20 rounded-full flex items-center justify-center mx-auto mb-3">
                    <svg className="w-6 h-6 text-blue-500" fill="currentColor" viewBox="0 0 20 20">
                      <path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                    </svg>
                  </div>
                  <h3 className="font-bold text-blue-500">High Liquidity</h3>
                  <p className="text-sm text-muted-foreground">Easy buying and selling conditions</p>
                </div>

                <div className="text-center p-4 neural-glow rounded-lg">
                  <div className="w-12 h-12 bg-purple-500/20 rounded-full flex items-center justify-center mx-auto mb-3">
                    <svg className="w-6 h-6 text-purple-500" fill="currentColor" viewBox="0 0 20 20">
                      <path d="M13 6a3 3 0 11-6 0 3 3 0 016 0zM18 8a2 2 0 11-4 0 2 2 0 014 0zM14 15a4 4 0 00-8 0v3h8v-3z"/>
                    </svg>
                  </div>
                  <h3 className="font-bold text-purple-500">Growing Community</h3>
                  <p className="text-sm text-muted-foreground">New researchers joining daily</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </main>
  )
}
