"use client"

import React, { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import Header from '@/components/Header'
import NFTCard from '@/components/NFTCard'

export default function DashboardPage() {
  const [activeTab, setActiveTab] = useState('overview')

  // Mock user data
  const userData = {
    name: 'Dr. Neural Scientist',
    username: '@neuralscientist',
    avatar: 'https://picsum.photos/100/100?random=user',
    address: '0x1234...5678',
    joined: 'March 2024',
    isVerified: true,
    portfolio: {
      totalValue: '12.5',
      totalNFTs: 23,
      collections: 8,
      earned: '5.2'
    }
  }

  // Mock NFT collections
  const myNFTs = [
    {
      title: "Neural Network #001",
      creator: "Dr. Neural Scientist",
      price: "2.1",
      image: "https://picsum.photos/400/400?random=1",
      rarity: "Rare",
      status: "Listed"
    },
    {
      title: "Quantum Brain Scan",
      creator: "Dr. Neural Scientist",
      price: "3.8",
      image: "https://picsum.photos/400/400?random=2",
      rarity: "Epic",
      status: "Owned"
    },
    {
      title: "Synaptic Patterns",
      creator: "Dr. Neural Scientist",
      price: "1.5",
      image: "https://picsum.photos/400/400?random=3",
      rarity: "Common",
      status: "Auction"
    },
    {
      title: "DNA Helix Art",
      creator: "Dr. Neural Scientist",
      price: "4.2",
      image: "https://picsum.photos/400/400?random=4",
      rarity: "Legendary",
      status: "Sold"
    }
  ]

  const recentActivity = [
    { type: 'Purchase', item: 'Neural Pathways #025', amount: '2.1 ETH', time: '2 hours ago', status: 'success' },
    { type: 'Sale', item: 'Quantum Dreams #003', amount: '1.8 ETH', time: '5 hours ago', status: 'success' },
    { type: 'Bid', item: 'Atomic Structure #012', amount: '0.5 ETH', time: '1 day ago', status: 'pending' },
    { type: 'Mint', item: 'Molecular Bond #007', amount: '0.08 ETH', time: '2 days ago', status: 'success' },
    { type: 'Transfer', item: 'Cell Division #019', amount: '0 ETH', time: '3 days ago', status: 'success' }
  ]

  const earnings = [
    { month: 'Jan', amount: 0.8 },
    { month: 'Feb', amount: 1.2 },
    { month: 'Mar', amount: 2.1 },
    { month: 'Apr', amount: 1.9 },
    { month: 'May', amount: 3.2 },
    { month: 'Jun', amount: 2.8 }
  ]

  const maxEarning = Math.max(...earnings.map(e => e.amount))

  return (
    <main className="min-h-screen bg-background">
      <Header />

      <div className="container mx-auto px-4 py-8">
        {/* Profile Header */}
        <div className="mb-8">
          <Card className="neural-glow">
            <CardContent className="p-8">
              <div className="flex flex-col md:flex-row items-start md:items-center justify-between">
                <div className="flex items-center space-x-6">
                  <Avatar className="w-24 h-24 ring-4 ring-primary/20">
                    <AvatarImage src={userData.avatar} alt={userData.name} />
                    <AvatarFallback className="text-2xl">{userData.name.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="flex items-center space-x-3 mb-2">
                      <h1 className="text-3xl font-bold scientific-heading">{userData.name}</h1>
                      {userData.isVerified && (
                        <svg className="w-6 h-6 text-primary" fill="currentColor" viewBox="0 0 20 20">
                          <path fillRule="evenodd" d="M6.267 3.455a3.066 3.066 0 001.745-.723 3.066 3.066 0 013.976 0 3.066 3.066 0 001.745.723 3.066 3.066 0 012.812 2.812c.051.643.304 1.254.723 1.745a3.066 3.066 0 010 3.976 3.066 3.066 0 00-.723 1.745 3.066 3.066 0 01-2.812 2.812 3.066 3.066 0 00-1.745.723 3.066 3.066 0 01-3.976 0 3.066 3.066 0 00-1.745-.723 3.066 3.066 0 01-2.812-2.812 3.066 3.066 0 00-.723-1.745 3.066 3.066 0 010-3.976 3.066 3.066 0 00.723-1.745 3.066 3.066 0 012.812-2.812zm7.44 5.252a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                        </svg>
                      )}
                    </div>
                    <p className="text-muted-foreground mb-1">{userData.username}</p>
                    <p className="text-sm text-muted-foreground">{userData.address} • Joined {userData.joined}</p>
                  </div>
                </div>
                <div className="mt-4 md:mt-0 flex space-x-2">
                  <Button variant="outline" className="electric-border">
                    Edit Profile
                  </Button>
                  <Button className="neural-glow">
                    Share Profile
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Portfolio Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-8">
          <Card className="neural-glow">
            <CardContent className="p-6 text-center">
              <h3 className="text-2xl font-bold scientific-heading">{userData.portfolio.totalValue} ETH</h3>
              <p className="text-sm text-muted-foreground">Portfolio Value</p>
              <p className="text-xs text-green-500 mt-1">+12.5% this month</p>
            </CardContent>
          </Card>
          <Card className="neural-glow">
            <CardContent className="p-6 text-center">
              <h3 className="text-2xl font-bold scientific-heading">{userData.portfolio.totalNFTs}</h3>
              <p className="text-sm text-muted-foreground">NFTs Owned</p>
              <p className="text-xs text-primary mt-1">Across {userData.portfolio.collections} collections</p>
            </CardContent>
          </Card>
          <Card className="neural-glow">
            <CardContent className="p-6 text-center">
              <h3 className="text-2xl font-bold scientific-heading">{userData.portfolio.earned} ETH</h3>
              <p className="text-sm text-muted-foreground">Total Earned</p>
              <p className="text-xs text-green-500 mt-1">From 12 sales</p>
            </CardContent>
          </Card>
          <Card className="neural-glow">
            <CardContent className="p-6 text-center">
              <h3 className="text-2xl font-bold scientific-heading">85%</h3>
              <p className="text-sm text-muted-foreground">Success Rate</p>
              <p className="text-xs text-primary mt-1">Profitable trades</p>
            </CardContent>
          </Card>
        </div>

        {/* Tab Navigation */}
        <div className="mb-8">
          <div className="flex space-x-6 border-b border-border">
            {[
              { id: 'overview', label: 'Overview' },
              { id: 'nfts', label: 'My NFTs' },
              { id: 'activity', label: 'Activity' },
              { id: 'analytics', label: 'Analytics' }
            ].map((tab) => (
              <button
                key={tab.id}
                className={`pb-4 px-2 text-sm font-medium transition-colors ${
                  activeTab === tab.id
                    ? 'text-primary border-b-2 border-primary'
                    : 'text-muted-foreground hover:text-foreground'
                }`}
                onClick={() => setActiveTab(tab.id)}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Tab Content */}
        <div className="space-y-8">
          {activeTab === 'overview' && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Recent Activity */}
              <Card className="neural-glow">
                <CardHeader>
                  <CardTitle className="scientific-heading">Recent Activity</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {recentActivity.slice(0, 5).map((activity, index) => (
                      <div key={index} className="flex items-center justify-between p-3 rounded-lg bg-secondary/20">
                        <div className="flex items-center space-x-3">
                          <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                            activity.status === 'success' ? 'bg-green-500/20 text-green-500' :
                            activity.status === 'pending' ? 'bg-yellow-500/20 text-yellow-500' :
                            'bg-red-500/20 text-red-500'
                          }`}>
                            {activity.type === 'Purchase' && '💰'}
                            {activity.type === 'Sale' && '💸'}
                            {activity.type === 'Bid' && '🔨'}
                            {activity.type === 'Mint' && '✨'}
                            {activity.type === 'Transfer' && '📤'}
                          </div>
                          <div>
                            <p className="font-medium">{activity.type} • {activity.item}</p>
                            <p className="text-xs text-muted-foreground">{activity.time}</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="font-semibold">{activity.amount}</p>
                          <Badge
                            variant={activity.status === 'success' ? 'default' : 'secondary'}
                            className="text-xs"
                          >
                            {activity.status}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Earnings Chart */}
              <Card className="neural-glow">
                <CardHeader>
                  <CardTitle className="scientific-heading">Monthly Earnings</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {earnings.map((earning, index) => (
                      <div key={index} className="flex items-center justify-between">
                        <span className="text-sm font-medium">{earning.month}</span>
                        <div className="flex items-center space-x-2 flex-1 ml-4">
                          <div className="flex-1 bg-secondary/20 rounded-full h-2">
                            <div
                              className="bg-primary h-2 rounded-full transition-all duration-300"
                              style={{ width: `${(earning.amount / maxEarning) * 100}%` }}
                            />
                          </div>
                          <span className="text-sm font-semibold w-16 text-right">{earning.amount} ETH</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {activeTab === 'nfts' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold scientific-heading">My NFT Collection</h2>
                <div className="flex space-x-2">
                  <Button variant="outline" size="sm">All</Button>
                  <Button variant="ghost" size="sm">Listed</Button>
                  <Button variant="ghost" size="sm">Owned</Button>
                  <Button variant="ghost" size="sm">Created</Button>
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {myNFTs.map((nft, index) => (
                  <div key={index} className="relative">
                    <NFTCard {...nft} />
                    <Badge
                      className={`absolute top-2 left-2 ${
                        nft.status === 'Listed' ? 'bg-green-500' :
                        nft.status === 'Auction' ? 'bg-yellow-500' :
                        nft.status === 'Sold' ? 'bg-red-500' :
                        'bg-blue-500'
                      }`}
                    >
                      {nft.status}
                    </Badge>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'activity' && (
            <Card className="neural-glow">
              <CardHeader>
                <CardTitle className="scientific-heading">Transaction History</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentActivity.map((activity, index) => (
                    <div key={index} className="flex items-center justify-between p-4 rounded-lg border border-border hover:bg-secondary/10 transition-colors">
                      <div className="flex items-center space-x-4">
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                          activity.status === 'success' ? 'bg-green-500/20 text-green-500' :
                          activity.status === 'pending' ? 'bg-yellow-500/20 text-yellow-500' :
                          'bg-red-500/20 text-red-500'
                        }`}>
                          {activity.type === 'Purchase' && '💰'}
                          {activity.type === 'Sale' && '💸'}
                          {activity.type === 'Bid' && '🔨'}
                          {activity.type === 'Mint' && '✨'}
                          {activity.type === 'Transfer' && '📤'}
                        </div>
                        <div>
                          <h3 className="font-semibold">{activity.type}</h3>
                          <p className="text-sm text-muted-foreground">{activity.item}</p>
                          <p className="text-xs text-muted-foreground">{activity.time}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-bold text-lg">{activity.amount}</p>
                        <Badge
                          variant={activity.status === 'success' ? 'default' : 'secondary'}
                          className="text-xs"
                        >
                          {activity.status}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {activeTab === 'analytics' && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <Card className="neural-glow">
                <CardHeader>
                  <CardTitle className="scientific-heading">Performance Metrics</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">Average Sale Price</span>
                    <span className="font-bold">2.3 ETH</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">Total Volume</span>
                    <span className="font-bold">18.7 ETH</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">Best Sale</span>
                    <span className="font-bold">4.2 ETH</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">Success Rate</span>
                    <span className="font-bold text-green-500">85%</span>
                  </div>
                </CardContent>
              </Card>

              <Card className="neural-glow">
                <CardHeader>
                  <CardTitle className="scientific-heading">Collection Breakdown</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {[
                    { category: 'Neural Networks', count: 8, percentage: 35 },
                    { category: 'Quantum Physics', count: 6, percentage: 26 },
                    { category: 'Molecular Biology', count: 5, percentage: 22 },
                    { category: 'Space Science', count: 4, percentage: 17 }
                  ].map((cat, index) => (
                    <div key={index} className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm font-medium">{cat.category}</span>
                        <span className="text-sm text-muted-foreground">{cat.count} NFTs</span>
                      </div>
                      <div className="w-full bg-secondary/20 rounded-full h-2">
                        <div
                          className="bg-primary h-2 rounded-full transition-all duration-300"
                          style={{ width: `${cat.percentage}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      </div>
    </main>
  )
}
