"use client"

import React, { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Checkbox } from '@/components/ui/checkbox'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import Header from '@/components/Header'

export default function AdminPage() {
  const [selectedUsers, setSelectedUsers] = useState<string[]>([])
  const [selectedCollections, setSelectedCollections] = useState<string[]>([])

  // Mock admin data
  const adminStats = {
    totalUsers: '12,456',
    totalNFTs: '89,234',
    totalVolume: '2,845',
    pendingReviews: '47'
  }

  const users = [
    {
      id: '1',
      name: 'Dr. Neural Scientist',
      email: 'neural@example.com',
      avatar: 'https://picsum.photos/100/100?random=1',
      status: 'Active',
      nfts: 23,
      volume: '15.6 ETH',
      joined: '2024-01-15',
      verified: true
    },
    {
      id: '2',
      name: 'Quantum Artist',
      email: 'quantum@example.com',
      avatar: 'https://picsum.photos/100/100?random=2',
      status: 'Active',
      nfts: 45,
      volume: '32.1 ETH',
      joined: '2024-02-03',
      verified: false
    },
    {
      id: '3',
      name: 'Molecular Designer',
      email: 'molecular@example.com',
      avatar: 'https://picsum.photos/100/100?random=3',
      status: 'Suspended',
      nfts: 12,
      volume: '8.9 ETH',
      joined: '2024-03-20',
      verified: true
    }
  ]

  const collections = [
    {
      id: '1',
      name: 'Neural Pathways',
      creator: 'Dr. Neural Scientist',
      items: 156,
      volume: '234.5 ETH',
      status: 'Featured',
      created: '2024-01-20'
    },
    {
      id: '2',
      name: 'Quantum Dreams',
      creator: 'Quantum Artist',
      items: 89,
      volume: '187.2 ETH',
      status: 'Approved',
      created: '2024-02-15'
    },
    {
      id: '3',
      name: 'Molecular Structures',
      creator: 'Molecular Designer',
      items: 67,
      volume: '98.7 ETH',
      status: 'Pending',
      created: '2024-03-10'
    }
  ]

  const pendingNFTs = [
    {
      id: '1',
      title: 'DNA Helix Visualization',
      creator: 'BioTech Artist',
      image: 'https://picsum.photos/100/100?random=4',
      category: 'Science',
      submitted: '2 hours ago'
    },
    {
      id: '2',
      title: 'Neural Network Model',
      creator: 'AI Researcher',
      image: 'https://picsum.photos/100/100?random=5',
      category: 'Technology',
      submitted: '5 hours ago'
    },
    {
      id: '3',
      title: 'Quantum Entanglement',
      creator: 'Physics Lab',
      image: 'https://picsum.photos/100/100?random=6',
      category: 'Physics',
      submitted: '1 day ago'
    }
  ]

  const recentTransactions = [
    {
      id: '1',
      nft: 'Neural Pathway #001',
      buyer: '0x1234...5678',
      seller: '0x9876...4321',
      price: '4.2 ETH',
      time: '10 min ago',
      fee: '0.105 ETH'
    },
    {
      id: '2',
      nft: 'Quantum Brain #045',
      buyer: '0x5555...8888',
      seller: '0x3333...1111',
      price: '3.8 ETH',
      time: '25 min ago',
      fee: '0.095 ETH'
    },
    {
      id: '3',
      nft: 'Molecular Bond #067',
      buyer: '0x7777...9999',
      seller: '0x2222...6666',
      price: '1.9 ETH',
      time: '1 hour ago',
      fee: '0.048 ETH'
    }
  ]

  const handleUserAction = (action: string, userIds: string[]) => {
    console.log(`${action} users:`, userIds)
    // Implement user actions
  }

  const handleCollectionAction = (action: string, collectionIds: string[]) => {
    console.log(`${action} collections:`, collectionIds)
    // Implement collection actions
  }

  const handleNFTReview = (nftId: string, action: 'approve' | 'reject') => {
    console.log(`${action} NFT:`, nftId)
    // Implement NFT review
  }

  return (
    <main className="min-h-screen bg-background">
      <Header />

      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold scientific-heading mb-2">
            Neural Admin Console
          </h1>
          <p className="text-lg text-muted-foreground">
            Manage your NFT marketplace with quantum-level precision
          </p>
        </div>

        {/* Admin Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-8">
          <Card className="neural-glow">
            <CardContent className="p-6 text-center">
              <h3 className="text-3xl font-bold scientific-heading">{adminStats.totalUsers}</h3>
              <p className="text-sm text-muted-foreground">Total Users</p>
              <p className="text-xs text-green-500 mt-1">+127 this week</p>
            </CardContent>
          </Card>
          <Card className="neural-glow">
            <CardContent className="p-6 text-center">
              <h3 className="text-3xl font-bold scientific-heading">{adminStats.totalNFTs}</h3>
              <p className="text-sm text-muted-foreground">Total NFTs</p>
              <p className="text-xs text-primary mt-1">+456 this week</p>
            </CardContent>
          </Card>
          <Card className="neural-glow">
            <CardContent className="p-6 text-center">
              <h3 className="text-3xl font-bold scientific-heading">{adminStats.totalVolume}</h3>
              <p className="text-sm text-muted-foreground">Volume (ETH)</p>
              <p className="text-xs text-green-500 mt-1">+18.2% this week</p>
            </CardContent>
          </Card>
          <Card className="neural-glow">
            <CardContent className="p-6 text-center">
              <h3 className="text-3xl font-bold scientific-heading text-yellow-500">{adminStats.pendingReviews}</h3>
              <p className="text-sm text-muted-foreground">Pending Reviews</p>
              <p className="text-xs text-yellow-500 mt-1">Requires attention</p>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="users" className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="users">Users</TabsTrigger>
            <TabsTrigger value="collections">Collections</TabsTrigger>
            <TabsTrigger value="nft-review">NFT Review</TabsTrigger>
            <TabsTrigger value="transactions">Transactions</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>

          {/* Users Management */}
          <TabsContent value="users">
            <Card className="neural-glow">
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle className="scientific-heading">User Management</CardTitle>
                  <div className="flex space-x-2">
                    <Button
                      variant="outline"
                      size="sm"
                      disabled={selectedUsers.length === 0}
                      onClick={() => handleUserAction('verify', selectedUsers)}
                    >
                      Verify Selected
                    </Button>
                    <Button
                      variant="destructive"
                      size="sm"
                      disabled={selectedUsers.length === 0}
                      onClick={() => handleUserAction('suspend', selectedUsers)}
                    >
                      Suspend Selected
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[50px]">
                        <Checkbox
                          checked={selectedUsers.length === users.length}
                          onCheckedChange={(checked) => {
                            if (checked) {
                              setSelectedUsers(users.map(u => u.id))
                            } else {
                              setSelectedUsers([])
                            }
                          }}
                        />
                      </TableHead>
                      <TableHead>User</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>NFTs</TableHead>
                      <TableHead>Volume</TableHead>
                      <TableHead>Joined</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {users.map((user) => (
                      <TableRow key={user.id}>
                        <TableCell>
                          <Checkbox
                            checked={selectedUsers.includes(user.id)}
                            onCheckedChange={(checked) => {
                              if (checked) {
                                setSelectedUsers([...selectedUsers, user.id])
                              } else {
                                setSelectedUsers(selectedUsers.filter(id => id !== user.id))
                              }
                            }}
                          />
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center space-x-3">
                            <Avatar className="w-10 h-10">
                              <AvatarImage src={user.avatar} alt={user.name} />
                              <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
                            </Avatar>
                            <div>
                              <div className="flex items-center space-x-2">
                                <span className="font-medium">{user.name}</span>
                                {user.verified && (
                                  <svg className="w-4 h-4 text-primary" fill="currentColor" viewBox="0 0 20 20">
                                    <path fillRule="evenodd" d="M6.267 3.455a3.066 3.066 0 001.745-.723 3.066 3.066 0 013.976 0 3.066 3.066 0 001.745.723 3.066 3.066 0 012.812 2.812c.051.643.304 1.254.723 1.745a3.066 3.066 0 010 3.976 3.066 3.066 0 00-.723 1.745 3.066 3.066 0 01-2.812 2.812 3.066 3.066 0 00-1.745.723 3.066 3.066 0 01-3.976 0 3.066 3.066 0 00-1.745-.723 3.066 3.066 0 01-2.812-2.812 3.066 3.066 0 00-.723-1.745 3.066 3.066 0 010-3.976 3.066 3.066 0 00.723-1.745 3.066 3.066 0 012.812-2.812zm7.44 5.252a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                                  </svg>
                                )}
                              </div>
                              <p className="text-sm text-muted-foreground">{user.email}</p>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge
                            variant={user.status === 'Active' ? 'default' : 'destructive'}
                          >
                            {user.status}
                          </Badge>
                        </TableCell>
                        <TableCell>{user.nfts}</TableCell>
                        <TableCell>{user.volume}</TableCell>
                        <TableCell>{user.joined}</TableCell>
                        <TableCell>
                          <div className="flex space-x-2">
                            <Button variant="outline" size="sm">
                              View
                            </Button>
                            <Button variant="ghost" size="sm">
                              Edit
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Collections Management */}
          <TabsContent value="collections">
            <Card className="neural-glow">
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle className="scientific-heading">Collection Management</CardTitle>
                  <div className="flex space-x-2">
                    <Button
                      variant="outline"
                      size="sm"
                      disabled={selectedCollections.length === 0}
                      onClick={() => handleCollectionAction('feature', selectedCollections)}
                    >
                      Feature Selected
                    </Button>
                    <Button
                      variant="destructive"
                      size="sm"
                      disabled={selectedCollections.length === 0}
                      onClick={() => handleCollectionAction('remove', selectedCollections)}
                    >
                      Remove Selected
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[50px]">
                        <Checkbox
                          checked={selectedCollections.length === collections.length}
                          onCheckedChange={(checked) => {
                            if (checked) {
                              setSelectedCollections(collections.map(c => c.id))
                            } else {
                              setSelectedCollections([])
                            }
                          }}
                        />
                      </TableHead>
                      <TableHead>Collection</TableHead>
                      <TableHead>Creator</TableHead>
                      <TableHead>Items</TableHead>
                      <TableHead>Volume</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {collections.map((collection) => (
                      <TableRow key={collection.id}>
                        <TableCell>
                          <Checkbox
                            checked={selectedCollections.includes(collection.id)}
                            onCheckedChange={(checked) => {
                              if (checked) {
                                setSelectedCollections([...selectedCollections, collection.id])
                              } else {
                                setSelectedCollections(selectedCollections.filter(id => id !== collection.id))
                              }
                            }}
                          />
                        </TableCell>
                        <TableCell>
                          <div>
                            <p className="font-medium">{collection.name}</p>
                            <p className="text-sm text-muted-foreground">Created {collection.created}</p>
                          </div>
                        </TableCell>
                        <TableCell>{collection.creator}</TableCell>
                        <TableCell>{collection.items}</TableCell>
                        <TableCell>{collection.volume}</TableCell>
                        <TableCell>
                          <Badge
                            variant={
                              collection.status === 'Featured' ? 'default' :
                              collection.status === 'Approved' ? 'secondary' :
                              'outline'
                            }
                          >
                            {collection.status}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex space-x-2">
                            <Button variant="outline" size="sm">
                              View
                            </Button>
                            <Select>
                              <SelectTrigger className="w-24 h-8">
                                <SelectValue placeholder="Status" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="featured">Featured</SelectItem>
                                <SelectItem value="approved">Approved</SelectItem>
                                <SelectItem value="pending">Pending</SelectItem>
                                <SelectItem value="rejected">Rejected</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* NFT Review */}
          <TabsContent value="nft-review">
            <Card className="neural-glow">
              <CardHeader>
                <CardTitle className="scientific-heading">NFT Content Review</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {pendingNFTs.map((nft) => (
                    <Card key={nft.id} className="neural-glow">
                      <CardContent className="p-4">
                        <div className="aspect-square bg-card rounded-lg overflow-hidden mb-4">
                          <img
                            src={nft.image}
                            alt={nft.title}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div className="space-y-2">
                          <h3 className="font-semibold">{nft.title}</h3>
                          <p className="text-sm text-muted-foreground">by {nft.creator}</p>
                          <div className="flex justify-between items-center">
                            <Badge variant="outline">{nft.category}</Badge>
                            <span className="text-xs text-muted-foreground">{nft.submitted}</span>
                          </div>
                          <div className="flex space-x-2 pt-2">
                            <Button
                              size="sm"
                              className="flex-1 neural-glow"
                              onClick={() => handleNFTReview(nft.id, 'approve')}
                            >
                              Approve
                            </Button>
                            <Button
                              size="sm"
                              variant="destructive"
                              className="flex-1"
                              onClick={() => handleNFTReview(nft.id, 'reject')}
                            >
                              Reject
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Transactions */}
          <TabsContent value="transactions">
            <Card className="neural-glow">
              <CardHeader>
                <CardTitle className="scientific-heading">Recent Transactions</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>NFT</TableHead>
                      <TableHead>Buyer</TableHead>
                      <TableHead>Seller</TableHead>
                      <TableHead>Price</TableHead>
                      <TableHead>Platform Fee</TableHead>
                      <TableHead>Time</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {recentTransactions.map((tx) => (
                      <TableRow key={tx.id}>
                        <TableCell className="font-medium">{tx.nft}</TableCell>
                        <TableCell className="font-mono text-sm">{tx.buyer}</TableCell>
                        <TableCell className="font-mono text-sm">{tx.seller}</TableCell>
                        <TableCell className="font-semibold text-primary">{tx.price}</TableCell>
                        <TableCell className="text-green-500">{tx.fee}</TableCell>
                        <TableCell className="text-muted-foreground">{tx.time}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Settings */}
          <TabsContent value="settings">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="neural-glow">
                <CardHeader>
                  <CardTitle className="scientific-heading">Marketplace Settings</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium mb-2">Platform Fee (%)</label>
                    <input
                      type="number"
                      step="0.1"
                      min="0"
                      max="10"
                      defaultValue="2.5"
                      className="w-full px-3 py-2 bg-background border border-border rounded-md focus:ring-2 focus:ring-primary focus:border-transparent"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Minimum Listing Price (ETH)</label>
                    <input
                      type="number"
                      step="0.001"
                      min="0"
                      defaultValue="0.001"
                      className="w-full px-3 py-2 bg-background border border-border rounded-md focus:ring-2 focus:ring-primary focus:border-transparent"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Maximum File Size (MB)</label>
                    <input
                      type="number"
                      min="1"
                      max="500"
                      defaultValue="100"
                      className="w-full px-3 py-2 bg-background border border-border rounded-md focus:ring-2 focus:ring-primary focus:border-transparent"
                    />
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="auto-approve" />
                    <label htmlFor="auto-approve" className="text-sm font-medium">
                      Auto-approve verified creators
                    </label>
                  </div>
                  <Button className="w-full neural-glow">
                    Save Settings
                  </Button>
                </CardContent>
              </Card>

              <Card className="neural-glow">
                <CardHeader>
                  <CardTitle className="scientific-heading">Featured Collections</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-sm text-muted-foreground">
                    Manage which collections appear on the homepage
                  </p>
                  {collections.filter(c => c.status === 'Featured').map((collection) => (
                    <div key={collection.id} className="flex items-center justify-between p-3 rounded-lg bg-secondary/20">
                      <div>
                        <h4 className="font-medium">{collection.name}</h4>
                        <p className="text-sm text-muted-foreground">by {collection.creator}</p>
                      </div>
                      <Button variant="outline" size="sm">
                        Remove
                      </Button>
                    </div>
                  ))}
                  <Button variant="outline" className="w-full">
                    Add Collection
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </main>
  )
}
