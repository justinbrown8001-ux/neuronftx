"use client"

import React from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import Header from '@/components/Header'

export default function DemoPagesPage() {
  const demoPages = [
    {
      name: 'Neural Art Gallery',
      slug: '/neural-gallery',
      description: 'A curated collection of neural network-generated art pieces',
      type: 'NFT Marketplace',
      status: 'online',
      visibility: 'public',
      features: ['AI-Generated Art', 'ETH Pricing', 'Neural Collections']
    },
    {
      name: 'Quantum Research Hub',
      slug: '/quantum-hub',
      description: 'Personal research hub for quantum computing and NFT experiments',
      type: 'User Profile Page',
      status: 'offline',
      visibility: 'private',
      features: ['Research Projects', 'Publications', 'Private Access']
    },
    {
      name: 'Scientific News',
      slug: '/sci-news',
      description: 'Latest news and updates from the scientific NFT community',
      type: 'Blog / News',
      status: 'online',
      visibility: 'public',
      features: ['Breaking News', 'Research Updates', 'Community Articles']
    }
  ]

  const handleVisitPage = (slug: string) => {
    window.open(`${window.location.origin}${slug}`, '_blank')
  }

  return (
    <main className="min-h-screen bg-background">
      <Header />

      <div className="container mx-auto px-4 py-8">
        <div className="mb-8 text-center">
          <h1 className="text-4xl font-bold scientific-heading mb-2">
            🎮 Demo Pages Showcase
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Explore these demo pages to see how the NeuroNFTX Page Registrar works.
            Each page is dynamically registered and managed through the system.
          </p>
        </div>

        {/* How It Works */}
        <Card className="neural-glow mb-8">
          <CardHeader>
            <CardTitle className="scientific-heading">🛠️ How the Page Registrar Works</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="text-center space-y-2">
                <div className="w-12 h-12 bg-primary/20 rounded-full flex items-center justify-center mx-auto">
                  <span className="text-primary font-bold">1</span>
                </div>
                <h3 className="font-semibold">Register</h3>
                <p className="text-sm text-muted-foreground">
                  Connect wallet and register your custom page with details
                </p>
              </div>
              <div className="text-center space-y-2">
                <div className="w-12 h-12 bg-primary/20 rounded-full flex items-center justify-center mx-auto">
                  <span className="text-primary font-bold">2</span>
                </div>
                <h3 className="font-semibold">Configure</h3>
                <p className="text-sm text-muted-foreground">
                  Set page type, visibility, ENS domain, and IPFS metadata
                </p>
              </div>
              <div className="text-center space-y-2">
                <div className="w-12 h-12 bg-primary/20 rounded-full flex items-center justify-center mx-auto">
                  <span className="text-primary font-bold">3</span>
                </div>
                <h3 className="font-semibold">Deploy</h3>
                <p className="text-sm text-muted-foreground">
                  Page goes live instantly with dynamic routing
                </p>
              </div>
              <div className="text-center space-y-2">
                <div className="w-12 h-12 bg-primary/20 rounded-full flex items-center justify-center mx-auto">
                  <span className="text-primary font-bold">4</span>
                </div>
                <h3 className="font-semibold">Manage</h3>
                <p className="text-sm text-muted-foreground">
                  Monitor analytics, update content, and manage access
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Demo Pages Grid */}
        <div className="space-y-6">
          <h2 className="text-2xl font-semibold scientific-heading">Demo Pages to Test</h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {demoPages.map((page, index) => (
              <Card key={index} className="neural-glow hover:glow-effect transition-all duration-300">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <CardTitle className="text-lg">{page.name}</CardTitle>
                    <div className="flex flex-col space-y-1">
                      <Badge
                        variant={page.status === 'online' ? 'default' : 'secondary'}
                        className="text-xs"
                      >
                        {page.status}
                      </Badge>
                      <Badge variant="outline" className="text-xs">
                        {page.visibility}
                      </Badge>
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    {page.description}
                  </p>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <p className="text-sm font-medium">Page Type:</p>
                    <Badge variant="outline" className="electric-border">
                      {page.type}
                    </Badge>
                  </div>

                  <div className="space-y-2">
                    <p className="text-sm font-medium">URL:</p>
                    <code className="text-xs bg-secondary/20 px-2 py-1 rounded block">
                      www.neuronftx.com{page.slug}
                    </code>
                  </div>

                  <div className="space-y-2">
                    <p className="text-sm font-medium">Features:</p>
                    <div className="flex flex-wrap gap-1">
                      {page.features.map((feature, idx) => (
                        <Badge key={idx} variant="secondary" className="text-xs">
                          {feature}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div className="flex space-x-2">
                    <Button
                      size="sm"
                      className="flex-1 neural-glow"
                      onClick={() => handleVisitPage(page.slug)}
                      disabled={page.status === 'offline'}
                    >
                      {page.status === 'offline' ? 'Offline' : 'Visit Page'}
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => navigator.clipboard.writeText(`${window.location.origin}${page.slug}`)}
                    >
                      Copy URL
                    </Button>
                  </div>

                  {page.status === 'offline' && (
                    <p className="text-xs text-yellow-500">
                      ⚠️ This page is currently offline for maintenance
                    </p>
                  )}

                  {page.visibility === 'private' && (
                    <p className="text-xs text-blue-500">
                      🔒 Private page - requires wallet authentication
                    </p>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Call to Action */}
        <Card className="neural-glow mt-8">
          <CardContent className="p-8 text-center">
            <h3 className="text-2xl font-semibold scientific-heading mb-4">
              Ready to Create Your Own Page?
            </h3>
            <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
              Use the NeuroNFTX Page Registrar to create custom pages for your NFT collections,
              research projects, or any other content. Connect your wallet and start building!
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                size="lg"
                className="neural-glow hover:glow-effect transition-all duration-300"
                onClick={() => window.location.href = '/page-registrar'}
              >
                🛠️ Open Page Registrar
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="electric-border"
                onClick={() => window.location.href = '/'}
              >
                🏠 Return to Homepage
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Technical Features */}
        <Card className="neural-glow mt-8">
          <CardHeader>
            <CardTitle className="scientific-heading">⚡ Technical Features</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <h4 className="font-semibold text-primary">Web3 Integration</h4>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li>• MetaMask wallet-based ownership verification</li>
                  <li>• ENS domain name integration</li>
                  <li>• IPFS metadata storage</li>
                  <li>• Blockchain-based page registration</li>
                </ul>
              </div>
              <div className="space-y-4">
                <h4 className="font-semibold text-primary">Dynamic Features</h4>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li>• Real-time page status management</li>
                  <li>• Public/private access controls</li>
                  <li>• Custom URL slug generation</li>
                  <li>• Live preview and editing</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </main>
  )
}
