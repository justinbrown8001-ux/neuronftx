"use client"

import React, { useState, useRef } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import Header from '@/components/Header'
import BlockchainStatus from '@/components/BlockchainStatus'
import { useWeb3 } from '@/contexts/Web3Context'

export default function CreateNFTPage() {
  const [uploadedFile, setUploadedFile] = useState<File | null>(null)
  const [preview, setPreview] = useState<string>('')
  const [isMinting, setIsMinting] = useState(false)
  const [mintingStatus, setMintingStatus] = useState<string>('')
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    category: 'Art',
    blockchain: 'Ethereum',
    royalties: '5',
    supply: '1',
    unlockableContent: false,
    freezeMetadata: true
  })
  const fileInputRef = useRef<HTMLInputElement>(null)
  const { isConnected, mintNFT, getGasPrice } = useWeb3()
  const [gasEstimate, setGasEstimate] = useState<string>('0')

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      setUploadedFile(file)
      const reader = new FileReader()
      reader.onload = (e) => {
        setPreview(e.target?.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  const handleInputChange = (field: string, value: string | boolean) => {
    setFormData(prev => ({ ...prev, [field]: value }))
  }

  const updateGasEstimate = async () => {
    if (isConnected) {
      try {
        const gas = await getGasPrice()
        setGasEstimate(gas)
      } catch (error) {
        console.error('Failed to get gas estimate:', error)
      }
    }
  }

  React.useEffect(() => {
    updateGasEstimate()
  }, [isConnected])

  const handleMintNFT = async () => {
    if (!isConnected) {
      alert('Please connect your wallet first')
      return
    }

    if (!uploadedFile || !formData.title) {
      alert('Please upload a file and enter a title')
      return
    }

    setIsMinting(true)
    setMintingStatus('Preparing metadata...')

    try {
      // In a real implementation, you would:
      // 1. Upload file to IPFS
      // 2. Create metadata JSON
      // 3. Upload metadata to IPFS
      // 4. Call smart contract mint function

      setMintingStatus('Uploading to IPFS...')
      await new Promise(resolve => setTimeout(resolve, 2000)) // Simulate IPFS upload

      setMintingStatus('Minting NFT...')
      const metadata = {
        name: formData.title,
        description: formData.description,
        image: 'ipfs://placeholder', // Would be real IPFS hash
        attributes: [
          { trait_type: 'Category', value: formData.category },
          { trait_type: 'Creator', value: 'Neural Artist' },
          { trait_type: 'Royalties', value: `${formData.royalties}%` }
        ]
      }

      const txHash = await mintNFT(metadata)
      setMintingStatus(`Success! Transaction: ${txHash}`)

      // Reset form after successful mint
      setTimeout(() => {
        setUploadedFile(null)
        setPreview('')
        setFormData({
          title: '',
          description: '',
          category: 'Art',
          blockchain: 'Ethereum',
          royalties: '5',
          supply: '1',
          unlockableContent: false,
          freezeMetadata: true
        })
        setMintingStatus('')
      }, 5000)

    } catch (error: any) {
      console.error('Minting failed:', error)
      setMintingStatus(`Error: ${error.message}`)
    } finally {
      setIsMinting(false)
    }
  }

  const blockchains = ['Ethereum', 'Polygon', 'Solana', 'BNB Chain']
  const categories = ['Art', 'Science', 'Music', 'Game', 'Photography', 'Video', '3D']

  return (
    <main className="min-h-screen bg-background">
      <Header />

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="mb-8 text-center">
            <h1 className="text-4xl font-bold scientific-heading mb-2">
              Create Neural NFT
            </h1>
            <p className="text-lg text-muted-foreground">
              Transform your scientific discoveries into digital art
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Upload Section */}
            <div className="space-y-6">
              <Card className="neural-glow">
                <CardHeader>
                  <CardTitle className="scientific-heading">Upload Artwork</CardTitle>
                </CardHeader>
                <CardContent>
                  <div
                    className="border-2 border-dashed border-border rounded-lg p-8 text-center cursor-pointer hover:border-primary transition-colors"
                    onClick={() => fileInputRef.current?.click()}
                  >
                    {preview ? (
                      <div className="space-y-4">
                        <img
                          src={preview}
                          alt="Preview"
                          className="max-w-full max-h-64 mx-auto rounded-lg"
                        />
                        <p className="text-sm text-muted-foreground">
                          {uploadedFile?.name} ({(uploadedFile?.size || 0 / 1024 / 1024).toFixed(2)} MB)
                        </p>
                        <Button variant="outline" size="sm">
                          Change File
                        </Button>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        <div className="w-16 h-16 mx-auto bg-primary/20 rounded-full flex items-center justify-center">
                          <svg className="w-8 h-8 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                          </svg>
                        </div>
                        <div>
                          <p className="text-lg font-medium">Drop your file here</p>
                          <p className="text-sm text-muted-foreground">
                            Supports JPG, PNG, GIF, MP4, WebM, MP3, WAV, GLB, GLTF
                          </p>
                          <p className="text-xs text-muted-foreground mt-2">
                            Max size: 100MB
                          </p>
                        </div>
                      </div>
                    )}
                  </div>
                  <input
                    ref={fileInputRef}
                    type="file"
                    className="hidden"
                    accept="image/*,video/*,audio/*,.glb,.gltf"
                    onChange={handleFileUpload}
                  />
                </CardContent>
              </Card>

              {/* Preview Card */}
              {preview && (
                <Card className="neural-glow">
                  <CardHeader>
                    <CardTitle className="scientific-heading">Preview</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="aspect-square bg-card rounded-lg overflow-hidden">
                      <img
                        src={preview}
                        alt="NFT Preview"
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="mt-4 space-y-2">
                      <h3 className="font-semibold">{formData.title || 'Untitled'}</h3>
                      <p className="text-sm text-muted-foreground">
                        {formData.description || 'No description provided'}
                      </p>
                      <Badge variant="outline" className="electric-border">
                        {formData.category}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>

            {/* Form Section */}
            <div className="space-y-6">
              <Card className="neural-glow">
                <CardHeader>
                  <CardTitle className="scientific-heading">NFT Details</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Title */}
                  <div>
                    <label className="block text-sm font-medium mb-2">Title *</label>
                    <input
                      type="text"
                      className="w-full px-3 py-2 bg-background border border-border rounded-md focus:ring-2 focus:ring-primary focus:border-transparent"
                      placeholder="Neural Network Visualization"
                      value={formData.title}
                      onChange={(e) => handleInputChange('title', e.target.value)}
                    />
                  </div>

                  {/* Description */}
                  <div>
                    <label className="block text-sm font-medium mb-2">Description</label>
                    <textarea
                      className="w-full px-3 py-2 bg-background border border-border rounded-md focus:ring-2 focus:ring-primary focus:border-transparent h-24 resize-none"
                      placeholder="Describe your scientific artwork..."
                      value={formData.description}
                      onChange={(e) => handleInputChange('description', e.target.value)}
                    />
                  </div>

                  {/* Category */}
                  <div>
                    <label className="block text-sm font-medium mb-2">Category</label>
                    <select
                      className="w-full px-3 py-2 bg-background border border-border rounded-md focus:ring-2 focus:ring-primary focus:border-transparent"
                      value={formData.category}
                      onChange={(e) => handleInputChange('category', e.target.value)}
                    >
                      {categories.map((category) => (
                        <option key={category} value={category}>{category}</option>
                      ))}
                    </select>
                  </div>

                  {/* Blockchain */}
                  <div>
                    <label className="block text-sm font-medium mb-2">Blockchain</label>
                    <select
                      className="w-full px-3 py-2 bg-background border border-border rounded-md focus:ring-2 focus:ring-primary focus:border-transparent"
                      value={formData.blockchain}
                      onChange={(e) => handleInputChange('blockchain', e.target.value)}
                    >
                      {blockchains.map((blockchain) => (
                        <option key={blockchain} value={blockchain}>{blockchain}</option>
                      ))}
                    </select>
                  </div>

                  {/* Royalties */}
                  <div>
                    <label className="block text-sm font-medium mb-2">Royalties (%)</label>
                    <input
                      type="number"
                      min="0"
                      max="20"
                      className="w-full px-3 py-2 bg-background border border-border rounded-md focus:ring-2 focus:ring-primary focus:border-transparent"
                      value={formData.royalties}
                      onChange={(e) => handleInputChange('royalties', e.target.value)}
                    />
                    <p className="text-xs text-muted-foreground mt-1">
                      Percentage you'll receive from future sales
                    </p>
                  </div>

                  {/* Supply */}
                  <div>
                    <label className="block text-sm font-medium mb-2">Supply</label>
                    <input
                      type="number"
                      min="1"
                      className="w-full px-3 py-2 bg-background border border-border rounded-md focus:ring-2 focus:ring-primary focus:border-transparent"
                      value={formData.supply}
                      onChange={(e) => handleInputChange('supply', e.target.value)}
                    />
                    <p className="text-xs text-muted-foreground mt-1">
                      Number of copies that can be minted
                    </p>
                  </div>
                </CardContent>
              </Card>

              {/* Advanced Settings */}
              <Card className="neural-glow">
                <CardHeader>
                  <CardTitle className="scientific-heading">Advanced Settings</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Unlockable Content</p>
                      <p className="text-sm text-muted-foreground">
                        Include exclusive content for the owner
                      </p>
                    </div>
                    <input
                      type="checkbox"
                      className="w-4 h-4 text-primary bg-background border-border rounded focus:ring-primary"
                      checked={formData.unlockableContent}
                      onChange={(e) => handleInputChange('unlockableContent', e.target.checked)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Freeze Metadata</p>
                      <p className="text-sm text-muted-foreground">
                        Permanently lock metadata on IPFS
                      </p>
                    </div>
                    <input
                      type="checkbox"
                      className="w-4 h-4 text-primary bg-background border-border rounded focus:ring-primary"
                      checked={formData.freezeMetadata}
                      onChange={(e) => handleInputChange('freezeMetadata', e.target.checked)}
                    />
                  </div>
                </CardContent>
              </Card>

              {/* Blockchain Status */}
              <BlockchainStatus />

              {/* Gas Fee Estimator */}
              <Card className="neural-glow">
                <CardContent className="p-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Estimated Gas Fee:</span>
                    <span className="font-medium">~{gasEstimate} Gwei</span>
                  </div>
                  <div className="flex justify-between items-center mt-2">
                    <span className="text-sm text-muted-foreground">Service Fee:</span>
                    <span className="font-medium">2.5%</span>
                  </div>
                  <div className="flex justify-between items-center mt-2">
                    <span className="text-sm text-muted-foreground">Network:</span>
                    <span className="font-medium">{formData.blockchain}</span>
                  </div>
                </CardContent>
              </Card>

              {/* Minting Status */}
              {mintingStatus && (
                <Card className="neural-glow">
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-2">
                      {isMinting && (
                        <div className="w-4 h-4 border-2 border-primary border-t-transparent rounded-full animate-spin"></div>
                      )}
                      <span className={`text-sm ${
                        mintingStatus.startsWith('Success') ? 'text-green-500' :
                        mintingStatus.startsWith('Error') ? 'text-red-500' :
                        'text-primary'
                      }`}>
                        {mintingStatus}
                      </span>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Create Button */}
              <Button
                className="w-full neural-glow hover:glow-effect transition-all duration-300 py-6 text-lg"
                disabled={!uploadedFile || !formData.title || !isConnected || isMinting}
                onClick={handleMintNFT}
              >
                {isMinting ? 'Minting...' : !isConnected ? 'Connect Wallet to Mint' : 'Create Neural NFT'}
              </Button>

              {!isConnected && (
                <p className="text-sm text-center text-muted-foreground">
                  Connect your wallet to mint NFTs on the blockchain
                </p>
              )}
            </div>
          </div>
        </div>
      </div>
    </main>
  )
}
