"use client"

import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Switch } from '@/components/ui/switch'
import { Label } from '@/components/ui/label'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import Header from '@/components/Header'
import { useWeb3 } from '@/contexts/Web3Context'
import { NEURONFTX_DOMAIN } from '@/components/DomainDisplay'

interface RegisteredPage {
  id: string
  name: string
  slug: string
  owner: string
  pageType: string
  status: 'online' | 'offline'
  visibility: 'public' | 'private'
  createdAt: string
  lastModified: string
  visits: number
}

export default function PageRegistrarPage() {
  const { isConnected, account } = useWeb3()
  const [formData, setFormData] = useState({
    pageName: '',
    urlSlug: '',
    pageType: '',
    status: true,
    visibility: 'public',
    description: '',
    ensName: '',
    ipfsHash: ''
  })
  const [isRegistering, setIsRegistering] = useState(false)
  const [registrationStatus, setRegistrationStatus] = useState('')
  const [registeredPages, setRegisteredPages] = useState<RegisteredPage[]>([
    {
      id: '1',
      name: 'Neural Art Gallery',
      slug: '/neural-gallery',
      owner: '0x1234...5678',
      pageType: 'NFT Marketplace',
      status: 'online',
      visibility: 'public',
      createdAt: '2024-01-15',
      lastModified: '2024-01-20',
      visits: 1250
    },
    {
      id: '2',
      name: 'Quantum Research Hub',
      slug: '/quantum-hub',
      owner: '0x9876...4321',
      pageType: 'User Profile Page',
      status: 'offline',
      visibility: 'private',
      createdAt: '2024-01-18',
      lastModified: '2024-01-19',
      visits: 890
    },
    {
      id: '3',
      name: 'Scientific News',
      slug: '/sci-news',
      owner: '0x5555...8888',
      pageType: 'Blog / News',
      status: 'online',
      visibility: 'public',
      createdAt: '2024-01-22',
      lastModified: '2024-01-23',
      visits: 2100
    }
  ])

  const pageTypes = [
    'Main Exchange Page',
    'NFT Marketplace',
    'User Profile Page',
    'Admin Dashboard',
    'Blog / News',
    'Collection Showcase',
    'Artist Portfolio',
    'Research Lab'
  ]

  // Auto-generate URL slug from page name
  useEffect(() => {
    const slug = formData.pageName
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-|-$/g, '')
    setFormData(prev => ({ ...prev, urlSlug: slug ? `/${slug}` : '' }))
  }, [formData.pageName])

  const handleInputChange = (field: string, value: string | boolean) => {
    setFormData(prev => ({ ...prev, [field]: value }))
  }

  const validateForm = () => {
    if (!isConnected) {
      setRegistrationStatus('Error: Please connect your wallet first')
      return false
    }
    if (!formData.pageName || !formData.pageType) {
      setRegistrationStatus('Error: Please fill in all required fields')
      return false
    }
    if (registeredPages.some(page => page.slug === formData.urlSlug)) {
      setRegistrationStatus('Error: This URL slug is already taken')
      return false
    }
    return true
  }

  const registerPage = async () => {
    if (!validateForm()) return

    setIsRegistering(true)
    setRegistrationStatus('Validating page configuration...')

    try {
      // Simulate page registration process
      await new Promise(resolve => setTimeout(resolve, 1000))
      setRegistrationStatus('Checking ENS availability...')

      await new Promise(resolve => setTimeout(resolve, 1500))
      setRegistrationStatus('Uploading metadata to IPFS...')

      await new Promise(resolve => setTimeout(resolve, 2000))
      setRegistrationStatus('Registering on blockchain...')

      await new Promise(resolve => setTimeout(resolve, 2500))

      // Create new registered page
      const newPage: RegisteredPage = {
        id: Date.now().toString(),
        name: formData.pageName,
        slug: formData.urlSlug,
        owner: account || '0x0000...0000',
        pageType: formData.pageType,
        status: formData.status ? 'online' : 'offline',
        visibility: formData.visibility as 'public' | 'private',
        createdAt: new Date().toISOString().split('T')[0],
        lastModified: new Date().toISOString().split('T')[0],
        visits: 0
      }

      setRegisteredPages(prev => [...prev, newPage])
      setRegistrationStatus(`Success! Page "${formData.pageName}" registered successfully`)

      // Reset form
      setTimeout(() => {
        setFormData({
          pageName: '',
          urlSlug: '',
          pageType: '',
          status: true,
          visibility: 'public',
          description: '',
          ensName: '',
          ipfsHash: ''
        })
        setRegistrationStatus('')
      }, 3000)

    } catch (error) {
      setRegistrationStatus('Error: Failed to register page')
    } finally {
      setIsRegistering(false)
    }
  }

  const copyPageURL = (slug: string) => {
    const fullURL = `https://www.neuronftx.com${slug}`
    navigator.clipboard.writeText(fullURL)
    setRegistrationStatus(`Copied: ${fullURL}`)
    setTimeout(() => setRegistrationStatus(''), 2000)
  }

  const previewPage = (slug: string) => {
    window.open(`${window.location.origin}${slug}`, '_blank')
  }

  const togglePageStatus = (pageId: string) => {
    setRegisteredPages(prev =>
      prev.map(page =>
        page.id === pageId
          ? { ...page, status: page.status === 'online' ? 'offline' : 'online' }
          : page
      )
    )
  }

  return (
    <main className="min-h-screen bg-background">
      <Header />

      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold scientific-heading mb-2">
            🛠️ NeuroNFTX Page Registrar
          </h1>
          <p className="text-lg text-muted-foreground">
            Register and activate custom pages/domains for the NeuroNFTX ecosystem
          </p>
        </div>

        <Tabs defaultValue="register" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="register">Register Page</TabsTrigger>
            <TabsTrigger value="manage">Manage Pages</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
          </TabsList>

          {/* Register New Page */}
          <TabsContent value="register">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Registration Form */}
              <Card className="neural-glow">
                <CardHeader>
                  <CardTitle className="scientific-heading">Page Registration Form</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Page Name */}
                  <div className="space-y-2">
                    <Label htmlFor="pageName">Page Name *</Label>
                    <input
                      id="pageName"
                      type="text"
                      placeholder="e.g., Neural Art Gallery"
                      className="w-full px-3 py-2 bg-background border border-border rounded-md focus:ring-2 focus:ring-primary focus:border-transparent"
                      value={formData.pageName}
                      onChange={(e) => handleInputChange('pageName', e.target.value)}
                    />
                  </div>

                  {/* URL Slug (Auto-filled) */}
                  <div className="space-y-2">
                    <Label htmlFor="urlSlug">URL Slug (auto-generated)</Label>
                    <input
                      id="urlSlug"
                      type="text"
                      className="w-full px-3 py-2 bg-secondary/20 border border-border rounded-md font-mono text-sm"
                      value={formData.urlSlug}
                      readOnly
                    />
                    <p className="text-xs text-muted-foreground">
                      Full URL: www.neuronftx.com{formData.urlSlug}
                    </p>
                  </div>

                  {/* Owner Wallet Address */}
                  <div className="space-y-2">
                    <Label>Owner Wallet Address</Label>
                    <div className="flex items-center space-x-2">
                      <input
                        type="text"
                        className="flex-1 px-3 py-2 bg-secondary/20 border border-border rounded-md font-mono text-sm"
                        value={account || 'Not connected'}
                        readOnly
                      />
                      {isConnected ? (
                        <Badge variant="default" className="electric-border">
                          <div className="w-2 h-2 bg-green-500 rounded-full mr-1"></div>
                          Verified
                        </Badge>
                      ) : (
                        <Badge variant="destructive">
                          Not Connected
                        </Badge>
                      )}
                    </div>
                  </div>

                  {/* Page Type */}
                  <div className="space-y-2">
                    <Label>Page Type *</Label>
                    <Select onValueChange={(value) => handleInputChange('pageType', value)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select page type" />
                      </SelectTrigger>
                      <SelectContent>
                        {pageTypes.map((type) => (
                          <SelectItem key={type} value={type}>
                            {type}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Page Description */}
                  <div className="space-y-2">
                    <Label htmlFor="description">Page Description</Label>
                    <textarea
                      id="description"
                      placeholder="Describe your page's purpose and content..."
                      className="w-full px-3 py-2 bg-background border border-border rounded-md focus:ring-2 focus:ring-primary focus:border-transparent h-20 resize-none"
                      value={formData.description}
                      onChange={(e) => handleInputChange('description', e.target.value)}
                    />
                  </div>

                  {/* Page Status Toggle */}
                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="status">Page Status</Label>
                      <p className="text-sm text-muted-foreground">
                        {formData.status ? 'Online - Publicly accessible' : 'Offline - Under development'}
                      </p>
                    </div>
                    <Switch
                      id="status"
                      checked={formData.status}
                      onCheckedChange={(checked) => handleInputChange('status', checked)}
                    />
                  </div>

                  {/* Visibility Settings */}
                  <div className="space-y-2">
                    <Label>Visibility Settings</Label>
                    <Select
                      value={formData.visibility}
                      onValueChange={(value) => handleInputChange('visibility', value)}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="public">Public - Anyone can access</SelectItem>
                        <SelectItem value="private">Private - Wallet-authenticated only</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </CardContent>
              </Card>

              {/* Web3 Integrations & Actions */}
              <div className="space-y-6">
                {/* Web3 Integrations */}
                <Card className="neural-glow">
                  <CardHeader>
                    <CardTitle className="scientific-heading">🌐 Web3 Integrations</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* ENS Integration */}
                    <div className="space-y-2">
                      <Label htmlFor="ensName">ENS Domain (optional)</Label>
                      <input
                        id="ensName"
                        type="text"
                        placeholder="e.g., neural-gallery.eth"
                        className="w-full px-3 py-2 bg-background border border-border rounded-md focus:ring-2 focus:ring-primary focus:border-transparent"
                        value={formData.ensName}
                        onChange={(e) => handleInputChange('ensName', e.target.value)}
                      />
                    </div>

                    {/* IPFS Integration */}
                    <div className="space-y-2">
                      <Label htmlFor="ipfsHash">IPFS Hash (optional)</Label>
                      <input
                        id="ipfsHash"
                        type="text"
                        placeholder="QmX... (metadata hash)"
                        className="w-full px-3 py-2 bg-background border border-border rounded-md focus:ring-2 focus:ring-primary focus:border-transparent font-mono text-sm"
                        value={formData.ipfsHash}
                        onChange={(e) => handleInputChange('ipfsHash', e.target.value)}
                      />
                    </div>

                    {/* Integration Status */}
                    <div className="grid grid-cols-2 gap-4 text-center">
                      <div className="space-y-1">
                        <div className="w-8 h-8 bg-primary/20 rounded-full flex items-center justify-center mx-auto">
                          <svg className="w-4 h-4 text-primary" fill="currentColor" viewBox="0 0 20 20">
                            <path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                          </svg>
                        </div>
                        <p className="text-xs text-muted-foreground">MetaMask Ready</p>
                      </div>
                      <div className="space-y-1">
                        <div className="w-8 h-8 bg-blue-500/20 rounded-full flex items-center justify-center mx-auto">
                          <svg className="w-4 h-4 text-blue-500" fill="currentColor" viewBox="0 0 20 20">
                            <path d="M3 4a1 1 0 011-1h12a1 1 0 011 1v2a1 1 0 01-1 1H4a1 1 0 01-1-1V4zM3 10a1 1 0 011-1h6a1 1 0 011 1v6a1 1 0 01-1 1H4a1 1 0 01-1-1v-6zM14 9a1 1 0 00-1 1v6a1 1 0 001 1h2a1 1 0 001-1v-6a1 1 0 00-1-1h-2z"/>
                          </svg>
                        </div>
                        <p className="text-xs text-muted-foreground">IPFS Ready</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Registration Status */}
                {registrationStatus && (
                  <Card className="neural-glow">
                    <CardContent className="p-4">
                      <div className="flex items-center space-x-2">
                        {isRegistering && (
                          <div className="w-4 h-4 border-2 border-primary border-t-transparent rounded-full animate-spin"></div>
                        )}
                        <span className={`text-sm ${
                          registrationStatus.startsWith('Success') ? 'text-green-500' :
                          registrationStatus.startsWith('Error') ? 'text-red-500' :
                          registrationStatus.startsWith('Copied') ? 'text-blue-500' :
                          'text-primary'
                        }`}>
                          {registrationStatus}
                        </span>
                      </div>
                    </CardContent>
                  </Card>
                )}

                {/* Action Buttons */}
                <div className="space-y-3">
                  <Button
                    className="w-full neural-glow hover:glow-effect transition-all duration-300 py-6 text-lg"
                    disabled={!isConnected || isRegistering || !formData.pageName || !formData.pageType}
                    onClick={registerPage}
                  >
                    {isRegistering ? 'Registering...' : '✅ Register Page'}
                  </Button>

                  <div className="grid grid-cols-2 gap-3">
                    <Button
                      variant="outline"
                      className="electric-border"
                      disabled={!formData.urlSlug}
                      onClick={() => previewPage(formData.urlSlug)}
                    >
                      🛠️ Preview Page
                    </Button>
                    <Button
                      variant="outline"
                      className="electric-border"
                      disabled={!formData.urlSlug}
                      onClick={() => copyPageURL(formData.urlSlug)}
                    >
                      🔗 Copy Page URL
                    </Button>
                  </div>
                </div>

                {!isConnected && (
                  <Card className="neural-glow border-yellow-500/20">
                    <CardContent className="p-4 text-center">
                      <div className="w-8 h-8 bg-yellow-500/20 rounded-full flex items-center justify-center mx-auto mb-2">
                        <svg className="w-4 h-4 text-yellow-500" fill="currentColor" viewBox="0 0 20 20">
                          <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                        </svg>
                      </div>
                      <p className="text-sm text-yellow-400 font-medium">Connect your wallet to register pages</p>
                      <p className="text-xs text-muted-foreground mt-1">
                        Web3 connection required for page ownership verification
                      </p>
                    </CardContent>
                  </Card>
                )}
              </div>
            </div>
          </TabsContent>

          {/* Manage Existing Pages */}
          <TabsContent value="manage">
            <Card className="neural-glow">
              <CardHeader>
                <CardTitle className="scientific-heading">Registered Pages Management</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Page Name</TableHead>
                      <TableHead>URL Slug</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Visibility</TableHead>
                      <TableHead>Owner</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {registeredPages.map((page) => (
                      <TableRow key={page.id}>
                        <TableCell className="font-medium">{page.name}</TableCell>
                        <TableCell className="font-mono text-sm">{page.slug}</TableCell>
                        <TableCell>{page.pageType}</TableCell>
                        <TableCell>
                          <div className="flex items-center space-x-2">
                            <Switch
                              checked={page.status === 'online'}
                              onCheckedChange={() => togglePageStatus(page.id)}
                            />
                            <Badge
                              variant={page.status === 'online' ? 'default' : 'secondary'}
                            >
                              {page.status}
                            </Badge>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline">
                            {page.visibility}
                          </Badge>
                        </TableCell>
                        <TableCell className="font-mono text-xs">{page.owner}</TableCell>
                        <TableCell>
                          <div className="flex space-x-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => previewPage(page.slug)}
                            >
                              Preview
                            </Button>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => copyPageURL(page.slug)}
                            >
                              Copy URL
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Analytics */}
          <TabsContent value="analytics">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card className="neural-glow">
                <CardContent className="p-6 text-center">
                  <h3 className="text-3xl font-bold scientific-heading">{registeredPages.length}</h3>
                  <p className="text-sm text-muted-foreground">Total Pages</p>
                  <p className="text-xs text-green-500 mt-1">
                    {registeredPages.filter(p => p.status === 'online').length} online
                  </p>
                </CardContent>
              </Card>
              <Card className="neural-glow">
                <CardContent className="p-6 text-center">
                  <h3 className="text-3xl font-bold scientific-heading">
                    {registeredPages.reduce((sum, page) => sum + page.visits, 0)}
                  </h3>
                  <p className="text-sm text-muted-foreground">Total Visits</p>
                  <p className="text-xs text-primary mt-1">Across all pages</p>
                </CardContent>
              </Card>
              <Card className="neural-glow">
                <CardContent className="p-6 text-center">
                  <h3 className="text-3xl font-bold scientific-heading">
                    {registeredPages.filter(p => p.visibility === 'public').length}
                  </h3>
                  <p className="text-sm text-muted-foreground">Public Pages</p>
                  <p className="text-xs text-blue-500 mt-1">Discoverable by all</p>
                </CardContent>
              </Card>
            </div>

            {/* Top Pages */}
            <Card className="neural-glow mt-6">
              <CardHeader>
                <CardTitle className="scientific-heading">Top Performing Pages</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {registeredPages
                    .sort((a, b) => b.visits - a.visits)
                    .slice(0, 5)
                    .map((page, index) => (
                      <div key={page.id} className="flex items-center justify-between p-3 rounded-lg bg-secondary/20">
                        <div className="flex items-center space-x-3">
                          <div className="w-8 h-8 bg-primary/20 rounded-full flex items-center justify-center font-bold">
                            {index + 1}
                          </div>
                          <div>
                            <h4 className="font-medium">{page.name}</h4>
                            <p className="text-sm text-muted-foreground">{page.slug}</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="font-bold">{page.visits.toLocaleString()}</p>
                          <p className="text-xs text-muted-foreground">visits</p>
                        </div>
                      </div>
                    ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </main>
  )
}
