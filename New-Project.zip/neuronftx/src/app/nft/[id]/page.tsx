"use client"

import React, { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import Header from '@/components/Header'
import ThreeDViewer from '@/components/ThreeDViewer'

export default function NFTDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const [isZoomed, setIsZoomed] = useState(false)
  const [activeTab, setActiveTab] = useState('description')
  const [nftId, setNftId] = useState<string>('')

  React.useEffect(() => {
    params.then((resolvedParams) => {
      setNftId(resolvedParams.id)
    })
  }, [params])

  // Mock NFT data (in real app, this would be fetched based on ID)
  const nft = {
    title: "Neural Pathways #001",
    creator: {
      name: "Dr. CyberArt",
      avatar: "https://picsum.photos/100/100?random=10",
      isVerified: true,
      address: "0x1234...5678"
    },
    price: "2.5",
    image: "https://picsum.photos/800/800?random=1",
    rarity: "Legendary",
    category: "Science",
    description: "A groundbreaking visualization of neural pathways in the human brain, created using advanced AI algorithms and quantum computing. This piece represents the intersection of neuroscience and digital art.",
    traits: [
      { name: "Background", value: "Cosmic Blue", rarity: "12%" },
      { name: "Pattern", value: "Neural Network", rarity: "5%" },
      { name: "Glow Effect", value: "Electric", rarity: "8%" },
      { name: "Complexity", value: "Ultra High", rarity: "2%" }
    ],
    blockchain: "Ethereum",
    tokenId: "12345",
    contractAddress: "0xabcd...efgh",
    royalties: "5%",
    history: [
      { event: "Minted", price: "0", date: "2 days ago", from: "", to: "Dr. CyberArt" },
      { event: "Listed", price: "2.5 ETH", date: "1 day ago", from: "Dr. CyberArt", to: "" }
    ]
  }

  return (
    <main className="min-h-screen bg-background">
      <Header />

      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* NFT Image Display */}
          <div className="space-y-6">
            <Card className="neural-glow overflow-hidden">
              <div
                className={`relative aspect-square cursor-zoom-in transition-transform duration-300 ${isZoomed ? 'scale-150' : 'scale-100'}`}
                onClick={() => setIsZoomed(!isZoomed)}
              >
                <img
                  src={nft.image}
                  alt={nft.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-4 right-4">
                  <Badge className="electric-border" variant="default">
                    {nft.rarity}
                  </Badge>
                </div>
              </div>
            </Card>

            {/* 3D Viewer */}
            <ThreeDViewer
              title={nft.title}
              modelUrl="/models/neural-network.glb"
            />

            {/* Additional Info Cards */}
            <div className="grid grid-cols-2 gap-4">
              <Card className="neural-glow">
                <CardContent className="p-4 text-center">
                  <h4 className="text-sm font-medium text-muted-foreground mb-1">Blockchain</h4>
                  <p className="font-semibold">{nft.blockchain}</p>
                </CardContent>
              </Card>
              <Card className="neural-glow">
                <CardContent className="p-4 text-center">
                  <h4 className="text-sm font-medium text-muted-foreground mb-1">Token ID</h4>
                  <p className="font-semibold">#{nft.tokenId}</p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* NFT Details */}
          <div className="space-y-8">
            {/* Title and Creator */}
            <div className="space-y-4">
              <h1 className="text-4xl font-bold scientific-heading">{nft.title}</h1>

              <div className="flex items-center space-x-3">
                <Avatar className="w-12 h-12">
                  <AvatarImage src={nft.creator.avatar} alt={nft.creator.name} />
                  <AvatarFallback>{nft.creator.name.charAt(0)}</AvatarFallback>
                </Avatar>
                <div>
                  <div className="flex items-center space-x-2">
                    <span className="font-medium">{nft.creator.name}</span>
                    {nft.creator.isVerified && (
                      <svg className="w-5 h-5 text-primary" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M6.267 3.455a3.066 3.066 0 001.745-.723 3.066 3.066 0 013.976 0 3.066 3.066 0 001.745.723 3.066 3.066 0 012.812 2.812c.051.643.304 1.254.723 1.745a3.066 3.066 0 010 3.976 3.066 3.066 0 00-.723 1.745 3.066 3.066 0 01-2.812 2.812 3.066 3.066 0 00-1.745.723 3.066 3.066 0 01-3.976 0 3.066 3.066 0 00-1.745-.723 3.066 3.066 0 01-2.812-2.812 3.066 3.066 0 00-.723-1.745 3.066 3.066 0 010-3.976 3.066 3.066 0 00.723-1.745 3.066 3.066 0 012.812-2.812zm7.44 5.252a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                      </svg>
                    )}
                  </div>
                  <p className="text-sm text-muted-foreground">{nft.creator.address}</p>
                </div>
              </div>
            </div>

            {/* Price and Actions */}
            <Card className="neural-glow">
              <CardContent className="p-6">
                <div className="space-y-4">
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Current Price</p>
                    <p className="text-3xl font-bold scientific-heading">{nft.price} ETH</p>
                    <p className="text-sm text-muted-foreground">≈ $4,250 USD</p>
                  </div>

                  <div className="flex space-x-3">
                    <Button className="flex-1 neural-glow hover:glow-effect transition-all duration-300">
                      Buy Now
                    </Button>
                    <Button variant="outline" className="flex-1 electric-border">
                      Place Bid
                    </Button>
                  </div>

                  <Button variant="ghost" className="w-full">
                    <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                    </svg>
                    Add to Favorites
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Tabs */}
            <div className="space-y-4">
              <div className="flex space-x-4 border-b border-border">
                {['description', 'traits', 'history'].map((tab) => (
                  <button
                    key={tab}
                    className={`pb-2 px-1 text-sm font-medium capitalize transition-colors ${
                      activeTab === tab
                        ? 'text-primary border-b-2 border-primary'
                        : 'text-muted-foreground hover:text-foreground'
                    }`}
                    onClick={() => setActiveTab(tab)}
                  >
                    {tab}
                  </button>
                ))}
              </div>

              <div className="min-h-48">
                {activeTab === 'description' && (
                  <div className="space-y-4">
                    <p className="text-muted-foreground leading-relaxed">{nft.description}</p>
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <span className="text-muted-foreground">Category:</span>
                        <span className="ml-2 font-medium">{nft.category}</span>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Royalties:</span>
                        <span className="ml-2 font-medium">{nft.royalties}</span>
                      </div>
                    </div>
                  </div>
                )}

                {activeTab === 'traits' && (
                  <div className="grid grid-cols-2 gap-4">
                    {nft.traits.map((trait, index) => (
                      <Card key={index} className="neural-glow">
                        <CardContent className="p-4">
                          <p className="text-xs text-muted-foreground uppercase tracking-wide">{trait.name}</p>
                          <p className="font-medium">{trait.value}</p>
                          <p className="text-xs text-primary">{trait.rarity} rarity</p>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}

                {activeTab === 'history' && (
                  <div className="space-y-4">
                    {nft.history.map((event, index) => (
                      <div key={index} className="flex items-center justify-between p-4 neural-glow rounded-lg">
                        <div className="flex items-center space-x-3">
                          <div className="w-8 h-8 bg-primary/20 rounded-full flex items-center justify-center">
                            <svg className="w-4 h-4 text-primary" fill="currentColor" viewBox="0 0 20 20">
                              <path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                            </svg>
                          </div>
                          <div>
                            <p className="font-medium">{event.event}</p>
                            <p className="text-sm text-muted-foreground">{event.date}</p>
                          </div>
                        </div>
                        <div className="text-right">
                          {event.price && <p className="font-medium">{event.price}</p>}
                          {event.from && <p className="text-xs text-muted-foreground">from {event.from}</p>}
                          {event.to && <p className="text-xs text-muted-foreground">to {event.to}</p>}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  )
}
