"use client"

import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import Header from '@/components/Header'
import { useWeb3 } from '@/contexts/Web3Context'

interface PageData {
  id: string
  name: string
  slug: string
  owner: string
  pageType: string
  status: 'online' | 'offline'
  visibility: 'public' | 'private'
  description: string
  content: string
  createdAt: string
  lastModified: string
  visits: number
}

// Mock registered pages database
const registeredPages: PageData[] = [
  {
    id: '1',
    name: 'Neural Art Gallery',
    slug: '/neural-gallery',
    owner: '0x1234...5678',
    pageType: 'NFT Marketplace',
    status: 'online',
    visibility: 'public',
    description: 'A curated collection of neural network-generated art pieces',
    content: `
      <div class="space-y-8">
        <div class="text-center">
          <h1 class="text-4xl font-bold scientific-heading mb-4">Neural Art Gallery</h1>
          <p class="text-lg text-muted-foreground">Discover AI-generated masterpieces created by neural networks</p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <div class="neural-glow rounded-lg p-4">
            <div class="aspect-square bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg mb-4"></div>
            <h3 class="font-semibold">Neural Dreams #001</h3>
            <p class="text-sm text-muted-foreground">AI-generated abstract art</p>
            <p class="text-primary font-bold">2.5 ETH</p>
          </div>

          <div class="neural-glow rounded-lg p-4">
            <div class="aspect-square bg-gradient-to-br from-green-500 to-blue-600 rounded-lg mb-4"></div>
            <h3 class="font-semibold">Quantum Patterns #042</h3>
            <p class="text-sm text-muted-foreground">Quantum-inspired visualization</p>
            <p class="text-primary font-bold">1.8 ETH</p>
          </div>

          <div class="neural-glow rounded-lg p-4">
            <div class="aspect-square bg-gradient-to-br from-red-500 to-pink-600 rounded-lg mb-4"></div>
            <h3 class="font-semibold">Synaptic Flow #103</h3>
            <p class="text-sm text-muted-foreground">Neural pathway visualization</p>
            <p class="text-primary font-bold">3.2 ETH</p>
          </div>
        </div>
      </div>
    `,
    createdAt: '2024-01-15',
    lastModified: '2024-01-20',
    visits: 1250
  },
  {
    id: '2',
    name: 'Quantum Research Hub',
    slug: '/quantum-hub',
    owner: '0x9876...4321',
    pageType: 'User Profile Page',
    status: 'offline',
    visibility: 'private',
    description: 'Personal research hub for quantum computing and NFT experiments',
    content: `
      <div class="space-y-8">
        <div class="text-center">
          <h1 class="text-4xl font-bold scientific-heading mb-4">Quantum Research Hub</h1>
          <p class="text-lg text-muted-foreground">Exploring the intersection of quantum computing and digital art</p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div class="neural-glow rounded-lg p-6">
            <h3 class="text-xl font-semibold scientific-heading mb-4">Research Projects</h3>
            <div class="space-y-3">
              <div class="p-3 bg-secondary/20 rounded-lg">
                <h4 class="font-medium">Quantum NFT Encryption</h4>
                <p class="text-sm text-muted-foreground">Securing digital assets with quantum cryptography</p>
              </div>
              <div class="p-3 bg-secondary/20 rounded-lg">
                <h4 class="font-medium">Neural Quantum Networks</h4>
                <p class="text-sm text-muted-foreground">Hybrid AI-quantum computing systems</p>
              </div>
            </div>
          </div>

          <div class="neural-glow rounded-lg p-6">
            <h3 class="text-xl font-semibold scientific-heading mb-4">Publications</h3>
            <div class="space-y-3">
              <div class="p-3 bg-secondary/20 rounded-lg">
                <h4 class="font-medium">Quantum-Enhanced NFT Marketplace</h4>
                <p class="text-sm text-muted-foreground">Published in Digital Assets Journal</p>
              </div>
              <div class="p-3 bg-secondary/20 rounded-lg">
                <h4 class="font-medium">Neural Art Generation via Quantum Algorithms</h4>
                <p class="text-sm text-muted-foreground">Presented at AI Art Conference 2024</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    `,
    createdAt: '2024-01-18',
    lastModified: '2024-01-19',
    visits: 890
  },
  {
    id: '3',
    name: 'Scientific News',
    slug: '/sci-news',
    owner: '0x5555...8888',
    pageType: 'Blog / News',
    status: 'online',
    visibility: 'public',
    description: 'Latest news and updates from the scientific NFT community',
    content: `
      <div class="space-y-8">
        <div class="text-center">
          <h1 class="text-4xl font-bold scientific-heading mb-4">Scientific News</h1>
          <p class="text-lg text-muted-foreground">Stay updated with the latest in scientific NFTs and blockchain research</p>
        </div>

        <div class="space-y-6">
          <article class="neural-glow rounded-lg p-6">
            <div class="flex items-start justify-between mb-4">
              <div>
                <h2 class="text-xl font-semibold mb-2">Breakthrough in Quantum NFT Encryption</h2>
                <p class="text-sm text-muted-foreground">Published 2 hours ago</p>
              </div>
              <Badge variant="default">Featured</Badge>
            </div>
            <p class="text-muted-foreground mb-4">
              Researchers at the Neural Institute have successfully implemented quantum-resistant encryption
              for NFT metadata, ensuring long-term security against quantum computing threats...
            </p>
            <Button variant="outline" size="sm">Read More</Button>
          </article>

          <article class="neural-glow rounded-lg p-6">
            <div class="flex items-start justify-between mb-4">
              <div>
                <h2 class="text-xl font-semibold mb-2">AI-Generated Art Reaches New Heights</h2>
                <p class="text-sm text-muted-foreground">Published 1 day ago</p>
              </div>
              <Badge variant="secondary">Technology</Badge>
            </div>
            <p class="text-muted-foreground mb-4">
              The latest neural network models are producing increasingly sophisticated art pieces,
              with some selling for record-breaking prices on decentralized marketplaces...
            </p>
            <Button variant="outline" size="sm">Read More</Button>
          </article>

          <article class="neural-glow rounded-lg p-6">
            <div class="flex items-start justify-between mb-4">
              <div>
                <h2 class="text-xl font-semibold mb-2">New Standards for Scientific NFT Verification</h2>
                <p class="text-sm text-muted-foreground">Published 3 days ago</p>
              </div>
              <Badge variant="outline">Research</Badge>
            </div>
            <p class="text-muted-foreground mb-4">
              The NeuroNFTX consortium announces new verification standards for scientific research
              represented as NFTs, ensuring authenticity and reproducibility...
            </p>
            <Button variant="outline" size="sm">Read More</Button>
          </article>
        </div>
      </div>
    `,
    createdAt: '2024-01-22',
    lastModified: '2024-01-23',
    visits: 2100
  }
]

export default function DynamicPage({ params }: { params: Promise<{ slug: string }> }) {
  const [pageSlug, setPageSlug] = useState<string>('')
  const [pageData, setPageData] = useState<PageData | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const { isConnected, account } = useWeb3()

  React.useEffect(() => {
    params.then((resolvedParams) => {
      setPageSlug(resolvedParams.slug)
    })
  }, [params])

  useEffect(() => {
    if (pageSlug) {
      // Simulate loading delay
      setTimeout(() => {
        const foundPage = registeredPages.find(page => page.slug === `/${pageSlug}`)

        if (foundPage) {
          // Check if page is online
          if (foundPage.status === 'offline') {
            setError('This page is currently offline for maintenance')
            setPageData(null)
          }
          // Check if user has access to private pages
          else if (foundPage.visibility === 'private' && (!isConnected || account !== foundPage.owner)) {
            setError('This page is private. Please connect the owner wallet to access.')
            setPageData(null)
          }
          else {
            setPageData(foundPage)
            setError(null)

            // Increment visit count (in real app, this would be done server-side)
            foundPage.visits += 1
          }
        } else {
          setError('Page not found. This page has not been registered in the NeuroNFTX ecosystem.')
          setPageData(null)
        }

        setIsLoading(false)
      }, 500)
    }
  }, [pageSlug, isConnected, account])

  if (isLoading) {
    return (
      <main className="min-h-screen bg-background">
        <Header />
        <div className="container mx-auto px-4 py-8">
          <div className="text-center space-y-4">
            <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto"></div>
            <h2 className="text-2xl font-semibold scientific-heading">Loading Neural Page...</h2>
            <p className="text-muted-foreground">Connecting to the NeuroNFTX ecosystem</p>
          </div>
        </div>
      </main>
    )
  }

  if (error) {
    return (
      <main className="min-h-screen bg-background">
        <Header />
        <div className="container mx-auto px-4 py-8">
          <Card className="neural-glow max-w-2xl mx-auto">
            <CardHeader>
              <CardTitle className="scientific-heading text-center text-2xl text-red-400">
                Access Denied
              </CardTitle>
            </CardHeader>
            <CardContent className="text-center space-y-4">
              <div className="w-16 h-16 bg-red-500/20 rounded-full flex items-center justify-center mx-auto">
                <svg className="w-8 h-8 text-red-500" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                </svg>
              </div>
              <p className="text-lg">{error}</p>
              <div className="space-y-2">
                <Button
                  onClick={() => window.location.href = '/page-registrar'}
                  className="neural-glow"
                >
                  Register a New Page
                </Button>
                <Button
                  variant="outline"
                  onClick={() => window.location.href = '/'}
                  className="electric-border"
                >
                  Return to Homepage
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    )
  }

  if (!pageData) {
    return (
      <main className="min-h-screen bg-background">
        <Header />
        <div className="container mx-auto px-4 py-8">
          <Card className="neural-glow max-w-2xl mx-auto">
            <CardHeader>
              <CardTitle className="scientific-heading text-center text-2xl">
                Page Not Found
              </CardTitle>
            </CardHeader>
            <CardContent className="text-center space-y-4">
              <div className="w-16 h-16 bg-yellow-500/20 rounded-full flex items-center justify-center mx-auto">
                <svg className="w-8 h-8 text-yellow-500" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
                </svg>
              </div>
              <div>
                <p className="text-lg mb-2">
                  The page "/{pageSlug}" has not been registered in the NeuroNFTX ecosystem.
                </p>
                <p className="text-muted-foreground mb-4">
                  Would you like to register this page and claim ownership?
                </p>
              </div>
              <div className="space-y-2">
                <Button
                  onClick={() => window.location.href = '/page-registrar'}
                  className="neural-glow"
                >
                  Register This Page
                </Button>
                <Button
                  variant="outline"
                  onClick={() => window.location.href = '/'}
                  className="electric-border"
                >
                  Return to Homepage
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    )
  }

  return (
    <main className="min-h-screen bg-background">
      <Header />

      <div className="container mx-auto px-4 py-8">
        {/* Page Header */}
        <div className="mb-8 text-center">
          <div className="flex items-center justify-center space-x-3 mb-4">
            <Badge variant="outline" className="electric-border">
              {pageData.pageType}
            </Badge>
            <Badge variant={pageData.status === 'online' ? 'default' : 'secondary'}>
              {pageData.status}
            </Badge>
            <Badge variant="outline">
              {pageData.visibility}
            </Badge>
          </div>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            {pageData.description}
          </p>
        </div>

        {/* Page Content */}
        <Card className="neural-glow">
          <CardContent className="p-8">
            <div
              className="prose prose-invert max-w-none"
              dangerouslySetInnerHTML={{ __html: pageData.content }}
            />
          </CardContent>
        </Card>

        {/* Page Footer */}
        <div className="mt-8 text-center space-y-4">
          <div className="flex items-center justify-center space-x-6 text-sm text-muted-foreground">
            <span>Created: {pageData.createdAt}</span>
            <span>•</span>
            <span>Last Modified: {pageData.lastModified}</span>
            <span>•</span>
            <span>{pageData.visits.toLocaleString()} visits</span>
          </div>

          <div className="flex items-center justify-center space-x-2 text-xs text-muted-foreground">
            <span>Owned by:</span>
            <code className="bg-secondary/20 px-2 py-1 rounded">{pageData.owner}</code>
            <span>•</span>
            <span>Powered by NeuroNFTX Page Registrar</span>
          </div>

          {isConnected && account === pageData.owner && (
            <Button
              variant="outline"
              size="sm"
              onClick={() => window.location.href = '/page-registrar'}
              className="electric-border"
            >
              Edit Page
            </Button>
          )}
        </div>
      </div>
    </main>
  )
}
