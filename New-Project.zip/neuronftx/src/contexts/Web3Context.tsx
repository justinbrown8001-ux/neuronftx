"use client"

import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react'
import { ethers } from 'ethers'

// Extend Window interface for wallet detection
declare global {
  interface Window {
    ethereum?: {
      isMetaMask?: boolean
      isCoinbaseWallet?: boolean
      request: (args: { method: string; params?: any[] }) => Promise<any>
      on: (event: string, callback: (...args: any[]) => void) => void
      removeListener: (event: string, callback: (...args: any[]) => void) => void
    }
    solana?: {
      isPhantom?: boolean
    }
  }
}

interface Web3ContextType {
  // Connection state
  isConnected: boolean
  isConnecting: boolean
  account: string | null
  balance: string | null
  chainId: number | null

  // Wallet functions
  connectWallet: (walletType: string) => Promise<void>
  disconnectWallet: () => void
  switchNetwork: (chainId: number) => Promise<void>

  // Contract interactions
  provider: ethers.BrowserProvider | null
  signer: ethers.JsonRpcSigner | null

  // NFT functions
  mintNFT: (metadata: any) => Promise<string>
  buyNFT: (tokenId: string, price: string) => Promise<string>
  listNFT: (tokenId: string, price: string) => Promise<string>
  getGasPrice: () => Promise<string>
}

const Web3Context = createContext<Web3ContextType | undefined>(undefined)

export const useWeb3 = () => {
  const context = useContext(Web3Context)
  if (!context) {
    throw new Error('useWeb3 must be used within a Web3Provider')
  }
  return context
}

interface Web3ProviderProps {
  children: ReactNode
}

export const Web3Provider: React.FC<Web3ProviderProps> = ({ children }) => {
  const [isConnected, setIsConnected] = useState(false)
  const [isConnecting, setIsConnecting] = useState(false)
  const [account, setAccount] = useState<string | null>(null)
  const [balance, setBalance] = useState<string | null>(null)
  const [chainId, setChainId] = useState<number | null>(null)
  const [provider, setProvider] = useState<ethers.BrowserProvider | null>(null)
  const [signer, setSigner] = useState<ethers.JsonRpcSigner | null>(null)

  // Network configurations
  const NETWORKS = {
    1: { name: 'Ethereum Mainnet', rpc: 'https://eth-mainnet.g.alchemy.com/v2/demo' },
    11155111: { name: 'Sepolia Testnet', rpc: 'https://eth-sepolia.g.alchemy.com/v2/demo' },
    137: { name: 'Polygon', rpc: 'https://polygon-rpc.com' },
    80001: { name: 'Mumbai Testnet', rpc: 'https://rpc-mumbai.maticvigil.com' }
  }

  // Smart contract addresses (mock - replace with real contracts)
  const CONTRACTS = {
    NFT_CONTRACT: '0x1234567890123456789012345678901234567890',
    MARKETPLACE_CONTRACT: '0x0987654321098765432109876543210987654321'
  }

  // Check if wallet is already connected on page load
  useEffect(() => {
    const checkConnection = async () => {
      if (typeof window !== 'undefined' && window.ethereum) {
        try {
          const accounts = await window.ethereum.request({ method: 'eth_accounts' })
          if (accounts.length > 0) {
            await initializeConnection(accounts[0])
          }
        } catch (error) {
          console.error('Failed to check wallet connection:', error)
        }
      }
    }

    checkConnection()
  }, [])

  const initializeConnection = async (account: string) => {
    try {
      if (!window.ethereum) throw new Error('No ethereum provider found')

      const provider = new ethers.BrowserProvider(window.ethereum as any)
      const signer = await provider.getSigner()
      const network = await provider.getNetwork()
      const balance = await provider.getBalance(account)

      setProvider(provider)
      setSigner(signer)
      setAccount(account)
      setBalance(ethers.formatEther(balance))
      setChainId(Number(network.chainId))
      setIsConnected(true)

      // Set up event listeners
      if (window.ethereum) {
        window.ethereum.on('accountsChanged', handleAccountsChanged)
        window.ethereum.on('chainChanged', handleChainChanged)
      }
    } catch (error) {
      console.error('Failed to initialize connection:', error)
    }
  }

  const handleAccountsChanged = (accounts: string[]) => {
    if (accounts.length === 0) {
      disconnectWallet()
    } else {
      initializeConnection(accounts[0])
    }
  }

  const handleChainChanged = (chainId: string) => {
    setChainId(parseInt(chainId, 16))
    // Reload to ensure proper network state
    window.location.reload()
  }

  const connectWallet = async (walletType: string) => {
    setIsConnecting(true)

    try {
      if (walletType === 'MetaMask' && window.ethereum?.isMetaMask) {
        const accounts = await window.ethereum.request({
          method: 'eth_requestAccounts',
        })
        await initializeConnection(accounts[0])
      } else if (walletType === 'Coinbase' && window.ethereum?.isCoinbaseWallet) {
        const accounts = await window.ethereum.request({
          method: 'eth_requestAccounts',
        })
        await initializeConnection(accounts[0])
      } else if (walletType === 'WalletConnect') {
        // In a real implementation, you'd use WalletConnect SDK
        throw new Error('WalletConnect integration requires additional setup')
      } else if (walletType === 'Phantom' && window.solana?.isPhantom) {
        // Phantom is for Solana, different implementation needed
        throw new Error('Solana integration requires different provider')
      } else {
        throw new Error(`${walletType} not detected or not supported`)
      }
    } catch (error: any) {
      console.error('Failed to connect wallet:', error)
      throw new Error(error.message || 'Failed to connect wallet')
    } finally {
      setIsConnecting(false)
    }
  }

  const disconnectWallet = () => {
    setIsConnected(false)
    setAccount(null)
    setBalance(null)
    setChainId(null)
    setProvider(null)
    setSigner(null)

    // Remove event listeners
    if (window.ethereum) {
      window.ethereum.removeListener('accountsChanged', handleAccountsChanged)
      window.ethereum.removeListener('chainChanged', handleChainChanged)
    }
  }

  const switchNetwork = async (targetChainId: number) => {
    if (!window.ethereum) throw new Error('No wallet detected')

    try {
      await window.ethereum.request({
        method: 'wallet_switchEthereumChain',
        params: [{ chainId: `0x${targetChainId.toString(16)}` }],
      })
    } catch (error: any) {
      // If network doesn't exist, add it
      if (error.code === 4902 && window.ethereum) {
        const networkConfig = NETWORKS[targetChainId as keyof typeof NETWORKS]
        if (networkConfig) {
          await window.ethereum.request({
            method: 'wallet_addEthereumChain',
            params: [{
              chainId: `0x${targetChainId.toString(16)}`,
              chainName: networkConfig.name,
              rpcUrls: [networkConfig.rpc],
            }],
          })
        }
      }
      throw error
    }
  }

  const getGasPrice = async (): Promise<string> => {
    if (!provider) throw new Error('Not connected to provider')

    const feeData = await provider.getFeeData()
    return ethers.formatUnits(feeData.gasPrice || 0, 'gwei')
  }

  const mintNFT = async (metadata: any): Promise<string> => {
    if (!signer) throw new Error('Wallet not connected')

    // Mock implementation - replace with real contract interaction
    try {
      // In a real implementation, you'd:
      // 1. Upload metadata to IPFS
      // 2. Call the mint function on your NFT contract
      // 3. Wait for transaction confirmation

      const tx = await signer.sendTransaction({
        to: CONTRACTS.NFT_CONTRACT,
        value: ethers.parseEther('0.01'), // Minting fee
        data: '0x' // Contract call data would go here
      })

      await tx.wait()
      return tx.hash
    } catch (error) {
      console.error('Minting failed:', error)
      throw error
    }
  }

  const buyNFT = async (tokenId: string, price: string): Promise<string> => {
    if (!signer) throw new Error('Wallet not connected')

    try {
      const tx = await signer.sendTransaction({
        to: CONTRACTS.MARKETPLACE_CONTRACT,
        value: ethers.parseEther(price),
        data: '0x' // Contract call data for buying NFT
      })

      await tx.wait()
      return tx.hash
    } catch (error) {
      console.error('Purchase failed:', error)
      throw error
    }
  }

  const listNFT = async (tokenId: string, price: string): Promise<string> => {
    if (!signer) throw new Error('Wallet not connected')

    try {
      const tx = await signer.sendTransaction({
        to: CONTRACTS.MARKETPLACE_CONTRACT,
        value: 0,
        data: '0x' // Contract call data for listing NFT
      })

      await tx.wait()
      return tx.hash
    } catch (error) {
      console.error('Listing failed:', error)
      throw error
    }
  }

  const value: Web3ContextType = {
    isConnected,
    isConnecting,
    account,
    balance,
    chainId,
    connectWallet,
    disconnectWallet,
    switchNetwork,
    provider,
    signer,
    mintNFT,
    buyNFT,
    listNFT,
    getGasPrice
  }

  return (
    <Web3Context.Provider value={value}>
      {children}
    </Web3Context.Provider>
  )
}
